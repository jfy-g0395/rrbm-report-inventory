/* ================================================================
   RRBM Packaging Supplies and Trading — Management System
   Main Application Script
   ================================================================ */

(function () {
  'use strict';

  // ── API base URL ──────────────────────────────────────────────────────────
  // Local dev  → '' + API_BASE + ''
  // Docker / production → ''  (nginx proxies /api/* to the backend container)
  // Local dev  (file:// or localhost): backend runs on its own port → use full URL.
  // Production (real hostname via nginx): nginx proxies /api/* → use relative URLs.
  const _h = window.location.hostname;
  const API_BASE = (_h === 'localhost' || _h === '127.0.0.1' || _h === '' || window.location.protocol === 'file:')
    ? 'http://localhost:8080'
    : '';

  const $ = (id) => document.getElementById(id);
  const $$ = (sel) => document.querySelectorAll(sel);

  let appState = {
    theme: 'light',
    cancelTargetId: null,
    codResumeTargetId: null,    // for COD resume password confirmation
    toastId: 0,
    cachedProducts: [],
    itemRowCounter: 0,
    deliveryLineCounter: 0,
    allOrders: [],              // today's orders cache (Order List view)
    inventoryAllProducts: [],   // full product cache for client-side filter
    addProductVerifiedKey: null,
    orderFormReady: false,      // form state persistence
    deliveryFormReady: false,   // form state persistence
    orderHistoryAll: [],        // order history cache for client-side search
    allUsers: [],               // users/employees cache
    refundTargetId: null,       // order id currently in the refund modal
    voidTargetId: null,         // order id currently in the void modal
  };

  function pad(n, w) { n = '' + n; while (n.length < w) n = '0' + n; return n; }

  function formatSource(src) {
    const map = {
      'WALK_IN': 'Walk-in', 'AGENT': 'Agent',
      'ECOMMERCE': 'E-Commerce', 'FACEBOOK_PAGE': 'Facebook Page',
      'RESELLER': 'Reseller', 'DISTRIBUTOR': 'Distributor',
    };
    return map[src] || src || '';
  }

  function formatOrderType(t) {
    const map = { 'STANDARD': 'Standard', 'PICK_UP': 'Pick Up', 'COD': 'COD', 'DELIVERY': 'Delivery' };
    return map[t] || t || 'Standard';
  }

  function formatDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    const m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return m[d.getMonth()] + ' ' + d.getDate() + ', ' + d.getFullYear();
  }

  function formatTime(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    let h = d.getHours(); const mm = pad(d.getMinutes(), 2);
    const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12;
    return h + ':' + mm + ' ' + ap;
  }

  function statusBadge(st) {
    const map = {
      'ACTIVE':    { dot: 'dot-active',    label: 'Active' },
      'PENDING':   { dot: 'dot-pending',   label: 'Pending' },
      'DELIVERED': { dot: 'dot-delivered', label: 'Delivered' },
      'CANCELLED': { dot: 'dot-cancelled', label: 'Cancelled' },
      'CLOSED':    { dot: 'dot-cancelled', label: 'Closed' },
    };
    const info = map[st] || { dot: '', label: st };
    return '<span class="status-dot ' + info.dot + '"></span>' + info.label;
  }

  // True for roles that can issue refunds / voids
  function canManageOrders() {
    const u = JSON.parse(sessionStorage.getItem('rrbm_user') || '{}');
    return ['SUPER_ADMIN', 'ADMINISTRATOR', 'ADMIN'].includes(u.role);
  }

  function roleBadge(role) {
    const map = {
      'SUPER_ADMIN':    { cls: 'badge-honey', label: 'Super Admin' },
      'ADMIN':          { cls: 'badge-ok',    label: 'Admin' },
      'ADMINISTRATOR':  { cls: 'badge-ok',    label: 'Administrator' },
      'STAFF':          { cls: 'badge-low',   label: 'Staff' },
      'STANDARD_USER':  { cls: 'badge-low',   label: 'Standard User' },
    };
    const info = map[role] || { cls: '', label: role };
    return '<span class="badge ' + info.cls + '">' + info.label + '</span>';
  }

  function authHeaders() {
    return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + sessionStorage.getItem('rrbm_token') };
  }

  function currentUserName() {
    try { return JSON.parse(sessionStorage.getItem('rrbm_user') || '{}').fullName || 'Admin'; }
    catch (e) { return 'Admin'; }
  }
  function currentUserRole() {
    try { return JSON.parse(sessionStorage.getItem('rrbm_user') || '{}').role || ''; }
    catch (e) { return ''; }
  }
  function currentUserEmail() {
    try { return JSON.parse(sessionStorage.getItem('rrbm_user') || '{}').email || ''; }
    catch (e) { return ''; }
  }
  function currentUserId() {
    try { return JSON.parse(sessionStorage.getItem('rrbm_user') || '{}').id || null; }
    catch (e) { return null; }
  }

  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
  }

  function isSuperAdmin() { return currentUserRole() === 'SUPER_ADMIN'; }

  function canManageEmployees() {
    const r = currentUserRole();
    return r === 'SUPER_ADMIN' || r === 'ADMINISTRATOR';
  }

  // ================================================================
  // MODAL HELPERS
  // ================================================================
  window.closeModal = function (id) {
    const el = $(id);
    if (el) el.classList.remove('open');
  };

  // ================================================================
  // LOGOUT CONFIRMATION
  // ================================================================
  window.askLogout = function () {
    $('modal-logout').classList.add('open');
  };

  window._doLogout = function () {
    closeModal('modal-logout');
    sessionStorage.removeItem('rrbm_token');
    sessionStorage.removeItem('rrbm_user');
    appState.orderFormReady = false;
    appState.deliveryFormReady = false;
    // Hide role-restricted UI
    applyRoleRestrictions(null);
    $('login-screen').style.display = 'flex';
    showToast('Logged out successfully', 'success');
  };

  // ================================================================
  // ROLE-BASED UI RESTRICTIONS + PAGE ACCESS CONTROL
  // ================================================================

  // Map view ID → page key used in allowedPages JSON array
  function viewToPageKey(view) {
    const map = {
      'new': 'orders', 'list': 'orders', 'order-history': 'orders',
      'inv': 'inventory',
      'delivery': 'receive-stocks',
      'rep': 'reports',
      'delivery-rep': 'delivery-reports',
      'activity-log': 'activity-log',
      'emp': 'employees',
      'expenses': 'expenses',
    };
    return map[view] || null; // null = no restriction (dash, set)
  }

  function getAllowedPages() {
    try {
      const u = JSON.parse(sessionStorage.getItem('rrbm_user') || '{}');
      if (!u.allowedPages) return null; // null = unrestricted
      return JSON.parse(u.allowedPages);
    } catch (e) { return null; }
  }

  function canAccessPage(view) {
    if (currentUserRole() === 'SUPER_ADMIN') return true;
    const key = viewToPageKey(view);
    if (!key) return true; // dashboard, settings — not page-restricted
    const pages = getAllowedPages();
    if (pages === null) return true; // null = unrestricted
    return pages.includes(key);
  }

  function applyRoleRestrictions(role) {
    const isSuper   = role === 'SUPER_ADMIN';
    const canManage = role === 'SUPER_ADMIN' || role === 'ADMINISTRATOR';
    // Settings nav — Super Admin only
    const navSet = $('nav-set');
    if (navSet) navSet.style.display = isSuper ? '' : 'none';
    // Employee List nav — Super Admin and Administrator only
    const navEmp = $('nav-emp');
    if (navEmp) navEmp.style.display = canManage ? '' : 'none';
    // Add Employee button — managers only
    const btnAddEmp = $('btn-add-employee');
    if (btnAddEmp) btnAddEmp.style.display = canManage ? '' : 'none';
    // Employees actions column header — managers only
    const empActHdr = $('emp-actions-header');
    if (empActHdr) empActHdr.style.display = canManage ? '' : 'none';

    // Page-based nav hiding (applied AFTER role restrictions)
    if (role) {
      applyPageAccessToNav();
    }
  }

  function applyPageAccessToNav() {
    if (currentUserRole() === 'SUPER_ADMIN') return; // Super Admin sees all nav
    const pages = getAllowedPages();
    if (pages === null) return; // unrestricted
    // Hide nav buttons whose page key is not in allowedPages
    document.querySelectorAll('.nav-item[data-view]').forEach(function (btn) {
      const view = btn.getAttribute('data-view');
      const key  = viewToPageKey(view);
      if (key && !pages.includes(key)) {
        btn.style.display = 'none';
      } else if (key) {
        btn.style.display = ''; // restore if previously hidden
      }
    });
  }

  // ================================================================
  // Render: Today's Orders (New Order view summary table)
  // ================================================================
  async function renderOrders() {
    const tb = $('orders-tbody');
    if (!tb) return;
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) { tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;">Please login first</td></tr>'; return; }

    try {
      const res = await fetch('' + API_BASE + '/api/orders/today', { headers: { 'Authorization': 'Bearer ' + token } });
      if (!res.ok) { tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;">Failed to load orders</td></tr>'; return; }
      const orders = await res.json();
      if (orders.length === 0) { tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;">No orders today yet</td></tr>'; return; }

      tb.innerHTML = orders.map(function (o) {
        const first = o.items && o.items[0];
        const itemText = first ? first.productName + (o.items.length > 1 ? ' +' + (o.items.length - 1) + ' more' : '') : '-';
        const totalQty = o.items ? o.items.reduce(function (s, i) { return s + i.quantity; }, 0) : 0;
        return '<tr>'
          + '<td><code style="font-size:11px;">' + o.id + '</code></td>'
          + '<td>' + o.customerName + '</td>'
          + '<td>' + itemText + '</td>'
          + '<td>' + totalQty + '</td>'
          + '<td>₱' + Number(o.total).toLocaleString() + '</td>'
          + '<td>' + formatSource(o.source) + '</td>'
          + '<td>' + o.paymentMode + '</td>'
          + '<td>' + statusBadge(o.status) + '</td>'
          + '</tr>';
      }).join('');
    } catch (err) {
      tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;">Connection error</td></tr>';
    }
  }

  // ================================================================
  // ORDER LIST — Today Only
  // ================================================================
  async function renderOrderList() {
    const tb = $('list-tbody');
    if (!tb) return;
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) { tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Please login first</td></tr>'; return; }

    tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Loading…</td></tr>';

    try {
      const res = await fetch('' + API_BASE + '/api/orders/today', { headers: { 'Authorization': 'Bearer ' + token } });
      if (!res.ok) { tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Failed to load orders</td></tr>'; return; }
      appState.allOrders = await res.json();
      const search = $('order-search');
      if (search) search.value = '';
      renderOrderRows(appState.allOrders);
    } catch (err) {
      tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Connection error</td></tr>';
    }
  }

  function renderOrderRows(orders) {
    const tb = $('list-tbody');
    if (!tb) return;
    if (orders.length === 0) {
      tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;padding:24px;">No results found</td></tr>';
      return;
    }

    tb.innerHTML = orders.map(function (o) {
      const first = o.items && o.items[0];
      const itemText = first ? first.productName + ' x' + first.quantity + (o.items.length > 1 ? ' +' + (o.items.length - 1) + ' more' : '') : '-';

      // Print receipt button always available
      const printBtn = '<button class="btn btn-secondary btn-sm" onclick="printOrderReceipt(\'' + o.id + '\')" title="Print Receipt"><i class="ti ti-printer"></i></button>';

      let actions = '';
      if (o.status === 'ACTIVE') {
        actions = '<button class="btn btn-success btn-sm" onclick="updateOrderStatus(\'' + o.id + '\', \'DELIVERED\')" title="Mark Delivered"><i class="ti ti-truck-delivery"></i></button>'
          + '<button class="btn btn-warning btn-sm" onclick="updateOrderStatus(\'' + o.id + '\', \'PENDING\')" title="Put on Hold"><i class="ti ti-clock-pause"></i></button>'
          + '<button class="btn btn-danger btn-sm" onclick="askCancel(\'' + o.id + '\')" title="Cancel"><i class="ti ti-x"></i></button>';
      } else if (o.status === 'PENDING') {
        // COD pending: admin password required to resume
        if (o.paymentMode === 'COD') {
          actions = '<button class="btn btn-primary btn-sm" onclick="askCodResume(\'' + o.id + '\')" title="Resume (COD — password required)"><i class="ti ti-player-play"></i><i class="ti ti-lock" style="font-size:9px;margin-left:2px;"></i></button>'
            + '<button class="btn btn-danger btn-sm" onclick="askCancel(\'' + o.id + '\')" title="Cancel"><i class="ti ti-x"></i></button>';
        } else {
          actions = '<button class="btn btn-primary btn-sm" onclick="updateOrderStatus(\'' + o.id + '\', \'ACTIVE\')" title="Resume"><i class="ti ti-player-play"></i></button>'
            + '<button class="btn btn-danger btn-sm" onclick="askCancel(\'' + o.id + '\')" title="Cancel"><i class="ti ti-x"></i></button>';
        }
      } else if (o.status === 'DELIVERED') {
        actions = '<span style="color:#10B981;font-size:12px;"><i class="ti ti-check"></i> Done</span>';
      } else if (o.status === 'CANCELLED') {
        actions = '<span style="color:#999;font-size:12px;">Cancelled</span>';
      }

      let srcDisplay = formatSource(o.source);
      if (o.source === 'AGENT' && o.agentName) srcDisplay += ' <span style="color:#666;font-size:11px;">(' + o.agentName + ')</span>';
      if ((o.source === 'RESELLER' || o.source === 'DISTRIBUTOR') && o.agentName) srcDisplay += ' <span style="color:#666;font-size:11px;">(' + o.agentName + ')</span>';
      if (o.source === 'ECOMMERCE' && o.ecommercePlatform) srcDisplay += ' <span style="color:#666;font-size:11px;">/ ' + o.ecommercePlatform.charAt(0) + o.ecommercePlatform.slice(1).toLowerCase() + '</span>';
      if (o.source === 'FACEBOOK_PAGE' && o.fbPage) srcDisplay += ' <span style="color:#666;font-size:11px;">(' + o.fbPage + ')</span>';

      const payBadge = o.paymentMode === 'COD'
        ? '<span style="color:#7C3AED;font-weight:600;font-size:11px;">COD</span>'
        : o.paymentMode;

      const cancelNote = (o.status === 'CANCELLED' && o.cancellationReason)
        ? '<div style="font-size:10px;color:#ef4444;margin-top:3px;white-space:normal;max-width:130px;line-height:1.3;">'
            + escapeHtml(o.cancellationReason) + '</div>'
        : '';

      return '<tr>'
        + '<td><code style="font-size:11px;">' + o.id + '</code></td>'
        + '<td>' + formatDate(o.createdAt) + '</td>'
        + '<td>' + o.customerName + '</td>'
        + '<td style="font-size:12px;">' + itemText + '</td>'
        + '<td>₱' + Number(o.total).toLocaleString() + '</td>'
        + '<td>' + srcDisplay + '</td>'
        + '<td>' + payBadge + '</td>'
        + '<td>' + statusBadge(o.status) + cancelNote + '</td>'
        + '<td><div class="d-flex gap-1">' + printBtn + actions + '</div></td>'
        + '</tr>';
    }).join('');
  }

  window.filterOrderList = function () {
    const q = (($('order-search') || {}).value || '').toLowerCase().trim();
    if (!q) { renderOrderRows(appState.allOrders); return; }
    const filtered = appState.allOrders.filter(function (o) {
      return o.id.toLowerCase().includes(q) || o.customerName.toLowerCase().includes(q);
    });
    renderOrderRows(filtered);
  };

  window.updateOrderStatus = async function (orderId, newStatus) {
    try {
      const res = await fetch('' + API_BASE + '/api/orders/' + orderId + '/status', {
        method: 'PUT', headers: authHeaders(), body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        const updated = await res.json();
        showToast('Order ' + orderId + ' → ' + updated.status, 'success');
        renderOrderList();
      } else {
        const err = await res.json();
        showToast('Error: ' + (err.message || 'Failed to update'), 'error');
      }
    } catch (error) {
      showToast('Connection error', 'error');
    }
  };

  // ================================================================
  // COD RESUME — admin password confirmation
  // ================================================================
  window.askCodResume = function (orderId) {
    appState.codResumeTargetId = orderId;
    $('cod-resume-order-id').textContent = orderId;
    $('cod-resume-password').value = '';
    $('modal-cod-resume').classList.add('open');
  };

  window.confirmCodResume = async function () {
    const password = ($('cod-resume-password') || {}).value || '';
    if (!password) { showToast('Password is required', 'error'); return; }

    const email = currentUserEmail();
    if (!email) { showToast('Session expired — please log in again', 'error'); return; }

    const btn = document.querySelector('#modal-cod-resume .btn-primary');
    if (btn) { btn.disabled = true; btn.textContent = 'Verifying…'; }

    try {
      const res = await fetch('' + API_BASE + '/api/auth/verify-password', {
        method: 'POST', headers: authHeaders(),
        body: JSON.stringify({ email: email, password: password })
      });
      if (res.ok) {
        closeModal('modal-cod-resume');
        await updateOrderStatus(appState.codResumeTargetId, 'ACTIVE');
      } else {
        showToast('Incorrect password — cannot resume COD order', 'error');
      }
    } catch (err) {
      showToast('Connection error', 'error');
    } finally {
      if (btn) { btn.disabled = false; btn.innerHTML = '<i class="ti ti-player-play"></i> Confirm &amp; Resume'; }
    }
  };

  // ================================================================
  // PRINT RECEIPT — PDF / print for a single order
  // ================================================================
  window.printOrderReceipt = function (orderId) {
    // Try to find the order in either the today cache or history cache
    const order = appState.allOrders.find(function (o) { return o.id === orderId; })
               || appState.orderHistoryAll.find(function (o) { return o.id === orderId; });
    if (!order) { showToast('Order data not available — try refreshing the list', 'error'); return; }

    const itemRows = (order.items || []).map(function (item) {
      const sub = Number(item.subtotal || 0).toFixed(2);
      return '<tr>'
        + '<td style="padding:8px 10px;border-bottom:1px solid #f0e8d0;">' + escapeHtml(item.productName) + '</td>'
        + '<td style="padding:8px 10px;border-bottom:1px solid #f0e8d0;text-align:center;">' + item.quantity + '</td>'
        + '<td style="padding:8px 10px;border-bottom:1px solid #f0e8d0;text-align:right;">₱' + Number(item.unitPrice || 0).toFixed(2) + '</td>'
        + '<td style="padding:8px 10px;border-bottom:1px solid #f0e8d0;text-align:right;">₱' + sub + '</td>'
        + '</tr>';
    }).join('');

    const subtotal = Number(order.subtotal || 0).toFixed(2);
    const discount = Number(order.discount || 0).toFixed(2);
    const total    = Number(order.total || 0).toFixed(2);
    const payMode  = order.paymentMode || 'CASH';
    const orderType = formatOrderType(order.orderType || 'STANDARD');
    const address  = order.address ? ('<div style="margin-top:4px;font-size:12px;color:#555;">📍 ' + escapeHtml(order.address) + '</div>') : '';
    const preparedBy = currentUserName();

    const w = window.open('', '_blank', 'width=680,height=880');
    if (!w) { showToast('Pop-up blocked — allow pop-ups and try again', 'error'); return; }

    w.document.write('<!DOCTYPE html><html><head><title>Receipt — ' + order.id + '</title>'
      + '<style>'
      + 'body{font-family:Arial,sans-serif;font-size:13px;margin:0;padding:24px;color:#1A1208;max-width:600px;margin:0 auto;}'
      + '.logo{text-align:center;margin-bottom:4px;}img{height:64px;}'
      + '.company{text-align:center;margin-bottom:2px;}'
      + '.company h2{margin:0;font-size:16px;color:#2C1A0E;}'
      + '.company p{margin:2px 0;font-size:11px;color:#666;}'
      + '.divider{border:none;border-top:2px dashed #ccc;margin:12px 0;}'
      + '.receipt-title{text-align:center;font-size:14px;font-weight:700;letter-spacing:2px;margin:8px 0;color:#D4860A;}'
      + '.meta{display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px;}'
      + '.customer{font-size:13px;margin-bottom:2px;}'
      + 'table{width:100%;border-collapse:collapse;margin:10px 0;}'
      + 'th{background:#FAD16A;padding:7px 10px;text-align:left;font-size:11px;text-transform:uppercase;}'
      + '.totals td{padding:5px 10px;font-size:12px;}'
      + '.total-row{font-weight:700;font-size:14px;border-top:2px solid #ccc;}'
      + '.sig-row{display:flex;gap:40px;margin-top:28px;}'
      + '.sig-box{flex:1;text-align:center;}'
      + '.sig-line{border-top:1px solid #333;margin-top:36px;padding-top:4px;font-size:11px;}'
      + '.btn-print{display:block;margin:20px auto 0;padding:9px 24px;background:#D4860A;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:13px;}'
      + '@media print{.btn-print{display:none;}}'
      + '</style></head><body>'
      + '<div class="logo"><img src="assets/logo-two.png" alt="RRBM" onerror="this.style.display=\'none\'"></div>'
      + '<div class="company">'
      + '<h2>RRBM Packaging Supplies and Trading</h2>'
      + '<p>116 Santan St., Fortune, Marikina City</p>'
      + '<p>📞 +63 966 846 9993</p>'
      + '</div>'
      + '<hr class="divider">'
      + '<div class="receipt-title">SALES RECEIPT</div>'
      + '<hr class="divider">'
      + '<div class="meta"><span><strong>Order #:</strong> ' + order.id + '</span><span><strong>Date:</strong> ' + formatDate(order.createdAt) + '</span></div>'
      + '<div class="meta"><span><strong>Type:</strong> ' + orderType + '</span><span><strong>Payment:</strong> ' + payMode + '</span></div>'
      + '<div class="customer"><strong>Customer:</strong> ' + escapeHtml(order.customerName) + '</div>'
      + address
      + '<hr class="divider">'
      + '<table><thead><tr><th>Item</th><th style="text-align:center;">Qty</th><th style="text-align:right;">Unit Price</th><th style="text-align:right;">Amount</th></tr></thead>'
      + '<tbody>' + itemRows + '</tbody></table>'
      + '<hr class="divider">'
      + '<table class="totals"><tbody>'
      + '<tr><td colspan="3" style="text-align:right;">Subtotal</td><td style="text-align:right;">₱' + subtotal + '</td></tr>'
      + '<tr><td colspan="3" style="text-align:right;">Discount</td><td style="text-align:right;">-₱' + discount + '</td></tr>'
      + '<tr class="total-row"><td colspan="3" style="text-align:right;">TOTAL</td><td style="text-align:right;">₱' + total + '</td></tr>'
      + '</tbody></table>'
      + '<hr class="divider">'
      + '<div class="sig-row">'
      + '<div class="sig-box"><div class="sig-line"><strong>' + escapeHtml(preparedBy) + '</strong><br>Prepared by</div></div>'
      + '<div class="sig-box"><div class="sig-line">Signature over Printed Name<br>Received by</div></div>'
      + '</div>'
      + '<button class="btn-print" onclick="window.print()">🖨️ Print / Save as PDF</button>'
      + '</body></html>');
    w.document.close();
  };

  // ================================================================
  // ORDER HISTORY — historical orders with date range + PDF
  // ================================================================
  window.renderOrderHistory = async function () {
    const tb = $('order-history-tbody');
    if (!tb) return;
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) { tb.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#999;">Please login first</td></tr>'; return; }

    tb.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#999;">Loading…</td></tr>';

    const start = ($('history-start') || {}).value;
    const end   = ($('history-end')   || {}).value;

    let url = '' + API_BASE + '/api/orders/history';
    const params = [];
    if (start) params.push('start=' + start);
    if (end)   params.push('end='   + end);
    if (params.length) url += '?' + params.join('&');

    try {
      const res = await fetch(url, { headers: { 'Authorization': 'Bearer ' + token } });
      if (!res.ok) { tb.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#999;">Failed to load</td></tr>'; return; }
      appState.orderHistoryAll = await res.json();
      if ($('history-search')) $('history-search').value = '';
      renderOrderHistoryRows(appState.orderHistoryAll);
    } catch (err) {
      tb.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#999;">Connection error</td></tr>';
    }
  };

  function renderOrderHistoryRows(orders) {
    const tb = $('order-history-tbody');
    if (!tb) return;
    if (!orders.length) {
      tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;padding:24px;">No orders found for this date range</td></tr>';
      return;
    }
    const canAdmin = canManageOrders();
    tb.innerHTML = orders.map(function (o) {
      const first = o.items && o.items[0];
      const itemText = first ? first.productName + ' x' + first.quantity + (o.items.length > 1 ? ' +' + (o.items.length - 1) + ' more' : '') : '-';
      const notCancelled = o.status !== 'CANCELLED';
      const safeId    = o.id.replace(/'/g, "\\'");
      const safeTotal = Number(o.total || 0).toFixed(2);

      // Action buttons
      let actions = '<button class="btn btn-secondary btn-sm" onclick="printOrderReceipt(\'' + safeId + '\')" title="Print Receipt" style="margin-right:3px;"><i class="ti ti-printer"></i></button>';
      actions    += '<button class="btn btn-sm" onclick="viewOrderLedger(\'' + safeId + '\')" title="View Ledger" style="background:#7C3AED;color:#fff;margin-right:3px;"><i class="ti ti-scale"></i></button>';
      if (canAdmin && notCancelled) {
        actions += '<button class="btn btn-sm" onclick="askRefund(\'' + safeId + '\',' + safeTotal + ')" title="Issue Refund" style="background:#F59E0B;color:#fff;margin-right:3px;"><i class="ti ti-receipt-refund"></i></button>';
        actions += '<button class="btn btn-sm btn-danger" onclick="askVoid(\'' + safeId + '\',' + safeTotal + ')" title="Post-Close Void"><i class="ti ti-ban"></i></button>';
      }

      const cancelReasonHtml = (o.status === 'CANCELLED' && o.cancellationReason)
        ? '<div style="font-size:10px;color:#ef4444;margin-top:3px;max-width:140px;white-space:normal;line-height:1.3;">'
            + escapeHtml(o.cancellationReason) + '</div>'
        : '';

      return '<tr>'
        + '<td><code style="font-size:11px;">' + o.id + '</code></td>'
        + '<td>' + formatDate(o.createdAt) + '</td>'
        + '<td>' + o.customerName + '</td>'
        + '<td style="font-size:12px;">' + itemText + '</td>'
        + '<td>₱' + Number(o.total).toLocaleString() + '</td>'
        + '<td>' + formatSource(o.source) + '</td>'
        + '<td>' + statusBadge(o.status) + cancelReasonHtml + '</td>'
        + '<td style="white-space:nowrap;">' + actions + '</td>'
        + '</tr>';
    }).join('');
  }

  window.filterOrderHistory = function () {
    const q = (($('history-search') || {}).value || '').toLowerCase().trim();
    if (!q) { renderOrderHistoryRows(appState.orderHistoryAll); return; }
    const filtered = appState.orderHistoryAll.filter(function (o) {
      return o.id.toLowerCase().includes(q) || o.customerName.toLowerCase().includes(q);
    });
    renderOrderHistoryRows(filtered);
  };

  window.exportOrderHistoryPDF = function () {
    const rows = document.querySelectorAll('#order-history-tbody tr');
    if (!rows.length || (rows.length === 1 && rows[0].querySelector('td[colspan]'))) {
      showToast('No data to export', 'error'); return;
    }
    const start = ($('history-start') || {}).value || '—';
    const end   = ($('history-end')   || {}).value || '—';
    const tableEl = $('order-history-table');
    const tableHtml = tableEl ? tableEl.outerHTML : '';
    const w = window.open('', '_blank', 'width=960,height=720');
    if (!w) { showToast('Pop-up blocked — allow pop-ups and try again', 'error'); return; }
    w.document.write('<!DOCTYPE html><html><head><title>Order History — RRBM</title>'
      + '<style>body{font-family:Arial,sans-serif;font-size:12px;margin:24px;color:#1A1208;}'
      + 'h2{color:#2C1A0E;margin-bottom:4px;}p{color:#888;font-size:11px;margin-bottom:16px;}'
      + 'button{margin-bottom:14px;padding:7px 18px;background:#D4860A;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:12px;}'
      + 'table{width:100%;border-collapse:collapse;}th{background:#FAD16A;padding:7px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.5px;}'
      + 'td{padding:7px 10px;border-bottom:1px solid #eee;font-size:12px;}code{font-family:monospace;}'
      + '@media print{button{display:none;}}'
      + '</style></head><body>'
      + '<h2>RRBM Packaging — Order History</h2>'
      + '<p>Period: ' + start + ' to ' + end + ' &nbsp;|&nbsp; Exported: ' + new Date().toLocaleString() + '</p>'
      + '<button onclick="window.print()">🖨️ Print / Save as PDF</button>'
      + tableHtml
      + '</body></html>');
    w.document.close();
  };

  // ================================================================
  // CLOSE DAILY SALES
  // ================================================================
  window.askCloseDailySales = function () {
    $('close-daily-key').value = '';
    $('modal-close-daily').classList.add('open');
  };

  window.confirmCloseDailySales = async function () {
    const key = ($('close-daily-key') || {}).value || '';
    if (!key) { showToast('Master key is required', 'error'); return; }

    const btn = document.querySelector('#modal-close-daily .btn-danger');
    if (btn) { btn.disabled = true; btn.textContent = 'Closing…'; }

    try {
      const res = await fetch('' + API_BASE + '/api/reports/close-daily', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ masterKey: key, userName: currentUserName() })
      });
      const data = await res.json();
      if (res.ok) {
        closeModal('modal-close-daily');
        showToast('Daily sales closed successfully!', 'success');
        renderOrderList();
      } else {
        showToast('Error: ' + (data.message || 'Failed to close'), 'error');
      }
    } catch (err) {
      showToast('Connection error', 'error');
    } finally {
      if (btn) { btn.disabled = false; btn.innerHTML = '<i class="ti ti-lock"></i> Close Daily Sales'; }
    }
  };

  // ================================================================
  // INVENTORY — two-tier search
  // ================================================================
  function getTagThresholds(tag) {
    if ((tag || '').toUpperCase() === 'HOT')  return { low: 5000, critical: 2500 };
    if ((tag || '').toUpperCase() === 'SLOW') return { low: 1000, critical: 500 };
    return { low: 2000, critical: 1000 };
  }

  function populateInvCategoryDropdown(categories, previousValue) {
    const sel = $('inv-category-filter');
    if (!sel) return;
    const prev = previousValue != null ? previousValue : sel.value;
    sel.innerHTML = '<option value="">All categories</option>';
    (categories || [])
      .filter(function (c) { return c != null && String(c).trim() !== ''; })
      .map(function (c) { return String(c).trim(); })
      .sort(function (a, b) { return a.localeCompare(b); })
      .forEach(function (c) {
        const opt = document.createElement('option');
        opt.value = c; opt.textContent = c;
        sel.appendChild(opt);
      });
    if (prev && [...sel.options].some(function (o) { return o.value === prev; })) sel.value = prev;
  }

  async function renderInventory() {
    const tb = $('inv-tbody');
    if (!tb) return;
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) { tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Please login first</td></tr>'; return; }

    const catSel = $('inv-category-filter');
    const prevCat = catSel ? catSel.value : '';
    tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Loading inventory…</td></tr>';

    try {
      const headers = { 'Authorization': 'Bearer ' + token };
      const [catRes, prodRes] = await Promise.all([
        fetch('' + API_BASE + '/api/products/categories', { headers }),
        fetch('' + API_BASE + '/api/products/all', { headers })
      ]);
      if (catRes.ok) populateInvCategoryDropdown(await catRes.json(), prevCat);
      if (!prodRes.ok) { tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Failed to load inventory</td></tr>'; return; }
      appState.inventoryAllProducts = await prodRes.json();
      applyInventoryFilters();
    } catch (err) {
      tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Connection error</td></tr>';
    }
  }

  window.filterInventory = function () { applyInventoryFilters(); };

  function applyInventoryFilters() {
    const tb = $('inv-tbody');
    if (!tb) return;
    let products = appState.inventoryAllProducts.slice();

    const filterCat = ($('inv-category-filter') ? $('inv-category-filter').value : '').trim();
    if (filterCat) products = products.filter(function (p) { return (p.category || '') === filterCat; });

    const kw = (($('inv-keyword') ? $('inv-keyword').value : '') || '').toLowerCase().trim();
    if (kw) products = products.filter(function (p) {
      return (p.name || '').toLowerCase().includes(kw)
          || (p.productCode || '').toLowerCase().includes(kw)
          || (p.sku || '').toLowerCase().includes(kw);
    });

    if (products.length === 0) {
      tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;padding:20px;">No products found</td></tr>';
      return;
    }

    tb.innerHTML = products.map(function (p) {
      const wh1 = p.stockWh1 || 0, wh2 = p.stockWh2 || 0, wh3 = p.stockWh3 || 0;
      const total = wh1 + wh2 + wh3;
      const tag = (p.sellingTag || 'SELLING').toUpperCase();

      const thresh = getTagThresholds(tag);
      const lowLevel = thresh.low;
      const critLevel = thresh.critical;

      const barMax = lowLevel * 2;
      const pct = Math.min(100, (total / barMax) * 100);

      let rowClass = '', badge = '', barColor = '#10B981';
      if (total === 0) {
        rowClass = 'row-oos'; badge = '<span class="badge badge-crit">Out of Stock</span>'; barColor = '#888';
      } else if (total <= critLevel) {
        rowClass = 'row-crit'; badge = '<span class="badge badge-crit">Critical</span>'; barColor = '#EF4444';
      } else if (total <= lowLevel) {
        rowClass = 'row-hot'; badge = '<span class="badge badge-low">Low</span>'; barColor = '#F59E0B';
      } else {
        badge = '<span class="badge badge-ok">OK</span>';
      }

      const tagSelect = '<select class="tag-select tag-select-' + tag + '" data-id="' + p.id + '" onchange="updateProductTag(this)">'
        + '<option value="HOT"' + (tag === 'HOT' ? ' selected' : '') + '>HOT</option>'
        + '<option value="SELLING"' + (tag === 'SELLING' ? ' selected' : '') + '>SELLING</option>'
        + '<option value="SLOW"' + (tag === 'SLOW' ? ' selected' : '') + '>SLOW</option>'
        + '</select>';

      const nameStyle = p.active ? 'font-weight:600;' : 'font-weight:600;color:#aaa;text-decoration:line-through;';
      const inactiveLabel = p.active ? '' : ' <span style="font-size:10px;color:#aaa;">(inactive)</span>';
      const codeCell = p.productCode
        ? '<code style="font-size:11px;letter-spacing:1px;">' + p.productCode + '</code>'
        : '<span style="color:#ccc;font-size:11px;">—</span>';

      return '<tr class="' + rowClass + '">'
        + '<td>' + codeCell + '</td>'
        + '<td><span style="' + nameStyle + '">' + p.name + '</span>' + inactiveLabel + '</td>'
        + '<td>' + tagSelect + '</td>'
        + '<td>' + wh1.toLocaleString() + '</td>'
        + '<td>' + wh2.toLocaleString() + '</td>'
        + '<td>' + wh3.toLocaleString() + '</td>'
        + '<td><strong>' + total.toLocaleString() + '</strong></td>'
        + '<td><div class="stock-bar-wrap"><div class="stock-bar" style="width:' + pct + '%;background:' + barColor + ';"></div></div></td>'
        + '<td>' + badge + '</td>'
        + '</tr>';
    }).join('');
  }

  window.updateProductTag = async function (selectEl) {
    const id = selectEl.getAttribute('data-id');
    const tag = selectEl.value;
    selectEl.className = 'tag-select tag-select-' + tag;
    try {
      const res = await fetch('' + API_BASE + '/api/products/' + id + '/tag', {
        method: 'PATCH',
        headers: authHeaders(),
        body: JSON.stringify({ sellingTag: tag, userName: currentUserName() })
      });
      if (res.ok) {
        const p = appState.inventoryAllProducts.find(function (x) { return String(x.id) === String(id); });
        if (p) p.sellingTag = tag;
        showToast('Tag updated to ' + tag, 'success');
        applyInventoryFilters();
      } else {
        const d = await res.json();
        showToast('Error: ' + (d.message || 'Failed to update tag'), 'error');
        applyInventoryFilters();
      }
    } catch (err) {
      showToast('Connection error', 'error');
      applyInventoryFilters();
    }
  };

  // ================================================================
  // ADD PRODUCT — two-step flow
  // ================================================================
  window.askAddProductKey = function () {
    appState.addProductVerifiedKey = null;
    $('addprod-key-input').value = '';
    $('modal-addprod-key').classList.add('open');
  };

  window.verifyAddProductKey = async function () {
    const key = ($('addprod-key-input') || {}).value || '';
    if (!key) { showToast('Master key is required', 'error'); return; }
    try {
      await fetch('' + API_BASE + '/api/reports/daily-status', { headers: authHeaders() });
      appState.addProductVerifiedKey = key;
      closeModal('modal-addprod-key');
      openAddProductForm();
    } catch (err) {
      showToast('Connection error. Is the backend running?', 'error');
    }
  };

  function openAddProductForm() {
    ['addprod-code','addprod-name','addprod-category','addprod-cost'].forEach(function (id) {
      if ($(id)) $(id).value = '';
    });
    if ($('addprod-price')) $('addprod-price').value = '';
    if ($('addprod-wh1')) $('addprod-wh1').value = '0';
    if ($('addprod-wh2')) $('addprod-wh2').value = '0';
    if ($('addprod-wh3')) $('addprod-wh3').value = '0';
    if ($('addprod-thresh-crit')) $('addprod-thresh-crit').value = 1000;
    if ($('addprod-thresh-low'))  $('addprod-thresh-low').value  = 2000;

    const dl = $('addprod-category-list');
    if (dl) {
      const cats = [...new Set(appState.inventoryAllProducts.map(function (p) { return p.category; }).filter(Boolean))].sort();
      dl.innerHTML = cats.map(function (c) { return '<option value="' + escapeHtml(c) + '">'; }).join('');
    }
    $('modal-addprod-form').classList.add('open');
  }

  window.submitAddProduct = async function () {
    const name     = (($('addprod-name')     || {}).value || '').trim();
    const category = (($('addprod-category') || {}).value || '').trim();
    const price    = parseFloat(($('addprod-price') || {}).value) || 0;
    const code     = (($('addprod-code')     || {}).value || '').trim().toUpperCase();

    if (!name)  { showToast('Product name is required', 'error'); return; }
    if (!category) { showToast('Category is required', 'error'); return; }
    if (price <= 0) { showToast('Unit price must be greater than 0', 'error'); return; }
    if (code && !/^[A-Z0-9]{1,6}$/.test(code)) {
      showToast('Product Code must be 1–6 alphanumeric characters', 'error'); return;
    }

    const body = {
      masterKey:         appState.addProductVerifiedKey,
      productCode:       code || null,
      name:              name,
      category:          category,
      sellingTag:        'SELLING',
      unitPrice:         price,
      unitCost:          parseFloat(($('addprod-cost') || {}).value) || 0,
      thresholdCritical: parseInt(($('addprod-thresh-crit') || {}).value) || 1000,
      thresholdLow:      parseInt(($('addprod-thresh-low')  || {}).value) || 2000,
      stockWh1:          parseInt(($('addprod-wh1') || {}).value) || 0,
      stockWh2:          parseInt(($('addprod-wh2') || {}).value) || 0,
      stockWh3:          parseInt(($('addprod-wh3') || {}).value) || 0,
      encodedByName:     currentUserName(),
    };

    try {
      const res = await fetch('' + API_BASE + '/api/products', {
        method: 'POST', headers: authHeaders(), body: JSON.stringify(body)
      });
      const data = await res.json();
      if (res.ok) {
        closeModal('modal-addprod-form');
        showToast('Product "' + name + '" added!', 'success');
        appState.addProductVerifiedKey = null;
        await renderInventory();
        await loadProducts();
      } else {
        showToast('Error: ' + (data.message || 'Failed to add product'), 'error');
      }
    } catch (err) {
      showToast('Connection error', 'error');
    }
  };

  // ================================================================
  // DELIVERY RECEIPT — searchable product dropdown, form state
  // ================================================================
  function addDeliveryLineRow() {
    appState.deliveryLineCounter = (appState.deliveryLineCounter || 0) + 1;
    const n = appState.deliveryLineCounter;
    const container = $('delivery-items-container');
    if (!container) return;

    container.insertAdjacentHTML('beforeend',
      '<div class="row align-items-end mb-2 delivery-line" id="delivery-row-' + n + '">'
      + '<div class="col-md-5"><label class="form-label">Product <span class="text-danger">*</span></label>'
      + '<div class="product-autocomplete-wrapper">'
      + '<input type="text" class="form-control delivery-product-input" id="d-prod-in-' + n + '" '
      + 'placeholder="Type to search products…" autocomplete="off">'
      + '<input type="hidden" class="delivery-product-id" id="d-prod-id-' + n + '" value="">'
      + '<div class="product-dropdown" id="d-prod-dd-' + n + '"></div>'
      + '</div></div>'
      + '<div class="col-md-2"><label class="form-label">Qty <span class="text-danger">*</span></label>'
      + '<input type="number" class="form-control delivery-qty" id="delivery-qty-' + n + '" min="1" value="1" /></div>'
      + '<div class="col-md-2"><label class="form-label">Warehouse</label>'
      + '<select class="form-select delivery-wh" id="delivery-wh-' + n + '"><option value="wh1">WH1</option><option value="wh2">WH2</option><option value="wh3">WH3</option></select></div>'
      + '<div class="col-md-2 text-end"><label class="form-label">&nbsp;</label>'
      + '<button type="button" class="btn btn-outline-danger btn-sm d-block" onclick="removeDeliveryLine(\'delivery-row-' + n + '\')"><i class="ti ti-trash"></i></button></div>'
      + '</div>');

    setupDeliveryAutocomplete(n);
  }

  function setupDeliveryAutocomplete(n) {
    const input    = $('d-prod-in-' + n);
    const dropdown = $('d-prod-dd-' + n);
    if (!input || !dropdown) return;

    function showDeliveryDropdown() {
      const t = input.value.toLowerCase().trim();
      const matches = t.length === 0
        ? appState.cachedProducts
        : appState.cachedProducts.filter(function (p) {
            return p.name.toLowerCase().includes(t)
                || (p.productCode || '').toLowerCase().includes(t)
                || (p.sku || '').toLowerCase().includes(t);
          });
      renderDeliveryProductDropdown(dropdown, matches, n);
    }

    input.addEventListener('input', showDeliveryDropdown);
    input.addEventListener('focus', showDeliveryDropdown);
    document.addEventListener('click', function (e) {
      if (!input.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove('show');
      }
    });
  }

  function renderDeliveryProductDropdown(dropdown, products, rowNum) {
    if (!products || products.length === 0) {
      dropdown.innerHTML = '<div class="product-dropdown-item" style="color:#999;cursor:default;">No products found</div>';
      dropdown.classList.add('show');
      return;
    }
    let html = '';
    products.slice(0, 50).forEach(function (p) {
      const wh1 = p.stockWh1 || 0, wh2 = p.stockWh2 || 0, wh3 = p.stockWh3 || 0;
      const total = wh1 + wh2 + wh3;
      const codeTag = p.productCode
        ? '<code style="font-size:10px;margin-right:5px;color:#888;">' + escapeHtml(p.productCode) + '</code>'
        : '';
      let stockClass = 'ok';
      if (total <= 0) stockClass = 'critical';
      else if (total <= (p.thresholdCritical || 0)) stockClass = 'critical';
      else if (total <= (p.thresholdLow || 0)) stockClass = 'low';

      html += '<div class="product-dropdown-item" '
        + 'data-id="' + p.id + '" '
        + 'data-name="' + escapeHtml(p.name) + '" '
        + 'data-row="' + rowNum + '">'
        + '<div style="flex:1;">'
        + '<div class="product-name">' + codeTag + escapeHtml(p.name) + '</div>'
        + '<div style="font-size:10px;color:#888;">Total: <span class="product-stock ' + stockClass + '">' + total.toLocaleString() + ' pcs</span></div>'
        + '</div>'
        + '</div>';
    });
    dropdown.innerHTML = html;
    dropdown.classList.add('show');

    dropdown.querySelectorAll('.product-dropdown-item[data-id]').forEach(function (item) {
      item.addEventListener('click', function () {
        const rn = this.getAttribute('data-row');
        $('d-prod-in-' + rn).value = this.getAttribute('data-name');
        $('d-prod-id-' + rn).value = this.getAttribute('data-id');
        dropdown.classList.remove('show');
      });
    });
  }

  window.removeDeliveryLine = function (rowId) {
    const row = $(rowId); if (row) row.remove();
  };

  async function initDeliveryForm() {
    await loadProducts();

    const encEl = $('delivery-encoded-by');
    if (encEl) encEl.value = currentUserName();

    if (appState.deliveryFormReady) return;

    if ($('delivery-receipt'))  $('delivery-receipt').value = '';
    if ($('delivery-receiver')) $('delivery-receiver').value = '';
    if ($('delivery-verifier')) $('delivery-verifier').value = '';
    if ($('delivery-notes'))    $('delivery-notes').value = '';

    const c = $('delivery-items-container');
    if (c) { c.innerHTML = ''; appState.deliveryLineCounter = 0; }
    addDeliveryLineRow();

    const addBtn = $('delivery-add-line');
    if (addBtn) {
      const fresh = addBtn.cloneNode(true);
      addBtn.parentNode.replaceChild(fresh, addBtn);
      fresh.addEventListener('click', addDeliveryLineRow);
    }
    appState.deliveryFormReady = true;
  }

  window.clearDeliveryForm = function () {
    appState.deliveryFormReady = false;
    initDeliveryForm();
  };

  window.submitDeliveryReceipt = async function () {
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) { showToast('Please login first', 'error'); return; }

    const receipt = (($('delivery-receipt') || {}).value || '').trim();
    if (!/^[A-Za-z0-9]{6,7}$/.test(receipt)) {
      showToast('Receipt # must be 6–7 letters or numbers (no spaces)', 'error'); return;
    }

    const receiverName = (($('delivery-receiver') || {}).value || '').trim();
    if (!receiverName) { showToast('Received by is required', 'error'); return; }

    const rows = $$('.delivery-line');
    if (rows.length === 0) { showToast('Add at least one line item', 'error'); return; }

    const items = [];
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const prodIdEl = row.querySelector('.delivery-product-id');
      const qtyEl    = row.querySelector('.delivery-qty');
      const whEl     = row.querySelector('.delivery-wh');

      if (!prodIdEl || !prodIdEl.value) {
        showToast('Select a product on every line', 'error'); return;
      }
      const qty = qtyEl ? parseInt(qtyEl.value, 10) : 0;
      if (!qty || qty < 1) { showToast('Quantity must be at least 1', 'error'); return; }
      items.push({ productId: parseInt(prodIdEl.value, 10), quantity: qty, warehouse: whEl ? whEl.value : 'wh1' });
    }

    const body = {
      receiptNumber: receipt,
      receiverName:  receiverName,
      verifierName:  (($('delivery-verifier') || {}).value || '').trim() || null,
      encodedByName: (($('delivery-encoded-by') || {}).value || '').trim() || currentUserName(),
      notes:         (($('delivery-notes') || {}).value || '').trim() || null,
      items:         items
    };

    try {
      const res = await fetch('' + API_BASE + '/api/products/delivery', {
        method: 'POST', headers: authHeaders(), body: JSON.stringify(body)
      });
      if (!res.ok) {
        let msg = 'Failed to post receipt';
        try { const d = await res.json(); msg = d.message || msg; } catch (e) {}
        showToast(msg, 'error'); return;
      }
      showToast('Stock updated from receipt ' + receipt, 'success');
      appState.deliveryFormReady = false;
      await loadProducts();
      initDeliveryForm();
    } catch (err) {
      showToast('Connection error. Is the backend running?', 'error');
    }
  };

  // ================================================================
  // DELIVERY REPORTS
  // ================================================================
  window.renderDeliveryReports = async function (all) {
    const tb = $('delivery-rep-tbody');
    if (!tb) return;
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) { tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;">Please login first</td></tr>'; return; }

    tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;">Loading…</td></tr>';

    let url = '' + API_BASE + '/api/reports/deliveries';
    if (!all) {
      const dateVal = ($('delivery-rep-date') || {}).value;
      if (dateVal) url += '/' + dateVal;
    }

    try {
      const res = await fetch(url, { headers: { 'Authorization': 'Bearer ' + token } });
      if (!res.ok) { tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;">Failed to load</td></tr>'; return; }
      const records = await res.json();
      if (!records.length) { tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;padding:20px;">No deliveries found</td></tr>'; return; }

      tb.innerHTML = records.map(function (r) {
        const notesCell = r.notes
          ? '<button class="btn btn-secondary btn-sm" onclick="viewNotes(\'' + escapeHtml(r.notes).replace(/'/g, '&#39;') + '\')"><i class="ti ti-notes"></i> View</button>'
          : '<span style="color:#999;font-size:11px;">—</span>';
        const itemsSummary = (r.items || []).length > 0
          ? (r.items || []).map(function (i) { return i.productName + ' ×' + i.quantity; }).join(', ')
          : '—';

        return '<tr>'
          + '<td><code style="font-size:11px;">' + r.receiptNumber + '</code></td>'
          + '<td>' + formatDate(r.reportDate || r.createdAt) + '</td>'
          + '<td>' + (r.receivedBy || '—') + '</td>'
          + '<td>' + (r.verifiedBy || '—') + '</td>'
          + '<td>' + (r.encodedByName || '—') + '</td>'
          + '<td style="font-size:11px;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="' + escapeHtml(itemsSummary) + '">' + escapeHtml(itemsSummary) + '</td>'
          + '<td>' + (r.totalQuantity || 0).toLocaleString() + '</td>'
          + '<td>' + notesCell + '</td>'
          + '</tr>';
      }).join('');
    } catch (err) {
      tb.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;">Connection error</td></tr>';
    }
  };

  window.viewNotes = function (notes) {
    const el = $('modal-notes-text');
    if (el) el.textContent = notes;
    $('modal-notes').classList.add('open');
  };

  // ================================================================
  // PRINT — Delivery Reports
  // ================================================================
  window.printDeliveryReports = function () {
    const tb = $('delivery-rep-tbody');
    if (!tb || tb.children.length === 0) { showToast('No data to print', 'error'); return; }

    const dateLabel = ($('delivery-rep-date') || {}).value || 'All';
    const rows = Array.from(tb.querySelectorAll('tr')).map(function (tr) {
      return Array.from(tr.querySelectorAll('td')).slice(0, 7) // skip Notes column
        .map(function (td) { return '<td style="padding:6px 10px;border:1px solid #ddd;font-size:12px;">' + td.innerHTML + '</td>'; })
        .join('');
    }).map(function (r) { return '<tr>' + r + '</tr>'; }).join('');

    const w = window.open('', '_blank', 'width=900,height=650');
    w.document.write(`
      <!DOCTYPE html><html><head><meta charset="UTF-8">
      <title>Delivery Reports — ${dateLabel}</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 24px; color: #111; }
        h2 { margin: 0 0 4px; } p { margin: 0 0 16px; font-size: 12px; color: #555; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f5f5f5; padding: 7px 10px; border: 1px solid #ddd; font-size: 12px; text-align: left; }
        @media print { button { display: none !important; } }
      </style></head><body>
      <h2>RRBM Packaging Supplies and Trading</h2>
      <p>Delivery Reports — ${dateLabel} &nbsp;|&nbsp; Printed: ${new Date().toLocaleString('en-PH')}</p>
      <table>
        <thead><tr>
          <th>Receipt #</th><th>Date</th><th>Received By</th>
          <th>Verified By</th><th>Encoded By</th><th>Products</th><th>Total Qty</th>
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <script>window.onload=function(){window.print();}<\/script>
      </body></html>`);
    w.document.close();
  };

  // ================================================================
  // PRINT — Daily / Monthly Reports summary
  // ================================================================
  window.printDailyReport = async function () {
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) { showToast('Please login first', 'error'); return; }

    // Fetch last 30 days of reports
    const end   = new Date(); end.setDate(end.getDate() - 1);
    const start = new Date(); start.setDate(start.getDate() - 30);
    const fmt   = function (d) { return d.toISOString().split('T')[0]; };

    try {
      const res = await fetch('' + API_BASE + '/api/reports/range?start=' + fmt(start) + '&end=' + fmt(end),
        { headers: { 'Authorization': 'Bearer ' + token } });
      if (!res.ok) { showToast('Failed to fetch report data', 'error'); return; }
      const reports = await res.json();

      if (!reports || reports.length === 0) { showToast('No closed reports in the last 30 days', 'error'); return; }

      const rows = reports.map(function (r) {
        return '<tr>'
          + '<td>' + (r.reportDate || '') + '</td>'
          + '<td style="text-align:right;">₱' + Number(r.totalRevenue || 0).toLocaleString('en-PH', {minimumFractionDigits:2}) + '</td>'
          + '<td style="text-align:right;">' + (r.totalOrders || 0) + '</td>'
          + '<td style="text-align:right;">' + (r.totalCancelled || 0) + '</td>'
          + '<td style="text-align:right;">' + (r.totalItemsSold || 0).toLocaleString() + '</td>'
          + '<td>' + (r.topProduct || '—') + ' ×' + (r.topProductQty || 0) + '</td>'
          + '</tr>';
      }).join('');

      const grandTotal = reports.reduce(function (sum, r) { return sum + Number(r.totalRevenue || 0); }, 0);

      const w = window.open('', '_blank', 'width=900,height=650');
      w.document.write(`
        <!DOCTYPE html><html><head><meta charset="UTF-8">
        <title>Sales Report</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 24px; color: #111; }
          h2 { margin: 0 0 4px; } p { margin: 0 0 16px; font-size: 12px; color: #555; }
          table { width: 100%; border-collapse: collapse; }
          th { background: #f5f5f5; padding: 7px 10px; border: 1px solid #ddd; font-size: 12px; text-align: left; }
          td { padding: 6px 10px; border: 1px solid #ddd; font-size: 12px; }
          tfoot td { font-weight: 700; background: #fafafa; }
          @media print { button { display: none !important; } }
        </style></head><body>
        <h2>RRBM Packaging Supplies and Trading</h2>
        <p>Daily Sales Report — Last 30 Days &nbsp;|&nbsp; Printed: ${new Date().toLocaleString('en-PH')}</p>
        <table>
          <thead><tr>
            <th>Date</th><th>Revenue</th><th>Orders</th><th>Cancelled</th><th>Items Sold</th><th>Top Product</th>
          </tr></thead>
          <tbody>${rows}</tbody>
          <tfoot><tr>
            <td>TOTAL</td>
            <td style="text-align:right;">₱${Number(grandTotal).toLocaleString('en-PH',{minimumFractionDigits:2})}</td>
            <td colspan="4"></td>
          </tr></tfoot>
        </table>
        <script>window.onload=function(){window.print();}<\/script>
        </body></html>`);
      w.document.close();
    } catch (err) {
      showToast('Connection error', 'error');
    }
  };

  // ================================================================
  // ACTIVITY LOG — fixed ID column (show userId, not entityId)
  // ================================================================
  window.renderActivityLog = async function (today) {
    const tb = $('activity-log-tbody');
    if (!tb) return;
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) { tb.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#999;">Please login first</td></tr>'; return; }

    tb.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#999;">Loading…</td></tr>';

    let url;
    if (today) {
      url = '' + API_BASE + '/api/activity-log/today';
      const todayStr = new Date().toISOString().split('T')[0];
      if ($('activity-log-date')) $('activity-log-date').value = todayStr;
    } else {
      const dateVal = ($('activity-log-date') || {}).value;
      url = dateVal
        ? '' + API_BASE + '/api/activity-log/' + dateVal
        : '' + API_BASE + '/api/activity-log/today';
    }

    try {
      const res = await fetch(url, { headers: { 'Authorization': 'Bearer ' + token } });
      if (!res.ok) { tb.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#999;">Failed to load</td></tr>'; return; }
      const logs = await res.json();
      if (!logs.length) { tb.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#999;padding:20px;">No activity for this date</td></tr>'; return; }

      const actionBadge = function (action) {
        const map = {
          'ADD_PRODUCT': 'badge-ok', 'RECEIVE_STOCK': 'badge-ok',
          'CANCEL_ORDER': 'badge-crit', 'CLOSE_DAILY_SALES': 'badge-honey',
          'LOGIN': 'badge-low', 'LOGOUT': 'badge-low',
          'UPDATE_PRODUCT_TAG': 'badge-low', 'CREATE_ORDER': 'badge-ok',
          'UPDATE_USER_ROLE': 'badge-honey', 'CREATE_USER': 'badge-ok',
          'UPDATE_USER_STATUS': 'badge-low',
          'ORDER_ON_HOLD': 'badge-honey', 'ORDER_RESUMED': 'badge-ok',
          'ORDER_STATUS_UPDATED': 'badge-low',
          'UPDATE_USER_PERMISSIONS': 'badge-honey',
          'DELIVER_ORDER': 'badge-ok',
        };
        const cls = map[action] || 'badge-low';
        return '<span class="badge ' + cls + '" style="font-size:10px;">' + action.replace(/_/g, ' ') + '</span>';
      };

      tb.innerHTML = logs.map(function (l) {
        // Entity/Ref column: show entityType + entityId together
        const entityRef = l.entityType
          ? '<span style="font-size:11px;color:var(--text-muted);">' + l.entityType + '</span>'
            + (l.entityId ? '<br><code style="font-size:10px;">' + l.entityId + '</code>' : '')
          : '—';
        // User ID column: show the actor's userId (employee ID)
        const userIdDisplay = l.userId
          ? '<code style="font-size:10px;">' + l.userId + '</code>'
          : '<span style="color:#ccc;">—</span>';

        return '<tr>'
          + '<td style="font-size:11px;color:var(--text-muted);">' + formatTime(l.createdAt) + '</td>'
          + '<td style="font-size:12px;">' + (l.userName || '—') + '</td>'
          + '<td>' + actionBadge(l.action) + '</td>'
          + '<td style="font-size:12px;max-width:260px;">' + (l.description || '—') + '</td>'
          + '<td style="font-size:11px;">' + entityRef + '</td>'
          + '<td>' + userIdDisplay + '</td>'
          + '</tr>';
      }).join('');
    } catch (err) {
      tb.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#999;">Connection error</td></tr>';
    }
  };

  // ================================================================
  // ================================================================
  // EXPENSES
  // ================================================================
  function initExpensesView() {
    // Set today's date
    const dateEl = $('exp-date');
    if (dateEl && !dateEl.value) {
      dateEl.value = new Date().toISOString().split('T')[0];
    }
    // Pre-fill admin name from session
    const nameEl = $('exp-admin-name');
    if (nameEl) {
      try {
        const u = JSON.parse(sessionStorage.getItem('rrbm_user') || '{}');
        nameEl.value = u.fullName || u.username || 'Admin';
      } catch (e) { nameEl.value = 'Admin'; }
    }
    loadTodaysExpenses();
  }

  window.addExpenseRow = function () {
    const container = $('exp-items-container');
    if (!container) return;
    const row = document.createElement('div');
    row.className = 'exp-item-row';
    row.style.cssText = 'display:grid;grid-template-columns:1fr 140px 36px;gap:8px;margin-bottom:8px;';
    row.innerHTML =
      '<input type="text" class="form-control exp-item-desc" placeholder="Item description" />' +
      '<input type="number" class="form-control exp-item-amount" placeholder="Amount" min="0" step="0.01" oninput="updateExpenseTotal()" />' +
      '<button class="btn btn-secondary btn-sm" onclick="removeExpenseRow(this)" title="Remove" style="padding:0 10px;">×</button>';
    container.appendChild(row);
  };

  window.removeExpenseRow = function (btn) {
    const container = $('exp-items-container');
    if (!container) return;
    if (container.querySelectorAll('.exp-item-row').length <= 1) {
      showToast('At least one item is required', 'error'); return;
    }
    btn.closest('.exp-item-row').remove();
    updateExpenseTotal();
  };

  window.updateExpenseTotal = function () {
    let total = 0;
    document.querySelectorAll('.exp-item-amount').forEach(function (inp) {
      total += parseFloat(inp.value) || 0;
    });
    const el = $('exp-running-total');
    if (el) el.textContent = '₱' + total.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  window.submitExpense = async function () {
    const date     = ($('exp-date')  || {}).value || '';
    const token    = sessionStorage.getItem('rrbm_token');
    if (!token) { showToast('Not authenticated', 'error'); return; }

    const items = [];
    document.querySelectorAll('.exp-item-row').forEach(function (row) {
      const desc   = (row.querySelector('.exp-item-desc')   || {}).value || '';
      const amount = parseFloat((row.querySelector('.exp-item-amount') || {}).value) || 0;
      if (desc.trim()) items.push({ itemDescription: desc.trim(), amount });
    });

    if (!date)           { showToast('Please select a date', 'error'); return; }
    if (items.length === 0) { showToast('Add at least one expense item', 'error'); return; }

    try {
      const res = await fetch(API_BASE + '/api/expenses', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ date, items })
      });
      const data = await res.json();
      if (res.ok) {
        showToast('Expense added successfully', 'success');
        // Clear items except first row
        const container = $('exp-items-container');
        if (container) {
          const rows = container.querySelectorAll('.exp-item-row');
          rows.forEach(function (r, i) {
            if (i === 0) {
              (r.querySelector('.exp-item-desc')   || {}).value = '';
              (r.querySelector('.exp-item-amount') || {}).value = '';
            } else {
              r.remove();
            }
          });
        }
        updateExpenseTotal();
        loadTodaysExpenses();
        renderDashboard(); // refresh expenses stat card
      } else {
        showToast('Error: ' + (data.error || 'Save failed'), 'error');
      }
    } catch (err) {
      showToast('Connection error', 'error');
    }
  };

  async function loadTodaysExpenses() {
    const tbody = $('exp-today-tbody');
    const totalEl = $('exp-today-total');
    if (!tbody) return;
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) return;
    try {
      const today = new Date().toISOString().split('T')[0];
      const res   = await fetch(API_BASE + '/api/expenses?date=' + today, { headers: authHeaders() });
      if (!res.ok) { tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:20px;">Error</td></tr>'; return; }
      const data  = await res.json();
      const fmt   = function (n) { return '₱' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };

      if (!data || data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:20px;">No expenses recorded today</td></tr>';
        if (totalEl) totalEl.textContent = '';
        return;
      }

      let grandTotal = 0;
      tbody.innerHTML = data.map(function (e) {
        grandTotal += parseFloat(e.totalAmount) || 0;
        const time  = e.createdAt ? new Date(e.createdAt).toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit' }) : '—';
        const itemsSummary = (e.items || []).map(function (i) {
          return escapeHtml(i.itemDescription) + ' — ' + fmt(i.amount);
        }).join('<br>');
        return '<tr>'
          + '<td style="font-size:12px;">' + time + '</td>'
          + '<td>' + escapeHtml(e.adminName) + '</td>'
          + '<td style="font-size:12px;color:var(--text-muted);">' + itemsSummary + '</td>'
          + '<td style="text-align:right;font-weight:600;">' + fmt(e.totalAmount) + '</td>'
          + '</tr>';
      }).join('');

      if (totalEl) totalEl.textContent = 'Total: ' + fmt(grandTotal);
    } catch (err) {
      tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:20px;">—</td></tr>';
    }
  }

  // EMPLOYEES / USER MANAGEMENT
  // ================================================================
  async function renderUsers() {
    const tb = $('emp-tbody');
    if (!tb) return;
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) { tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Please login first</td></tr>'; return; }

    tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Loading…</td></tr>';

    try {
      const res = await fetch('' + API_BASE + '/api/users', { headers: { 'Authorization': 'Bearer ' + token } });
      if (!res.ok) { tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Failed to load users</td></tr>'; return; }
      appState.allUsers = await res.json();
      const myId   = String(currentUserId());
      const canMgr = canManageEmployees();

      tb.innerHTML = appState.allUsers.map(function (u) {
        const statusDot = u.status === 'ACTIVE'   ? '<span class="status-dot dot-active"></span>Active'
          : u.status === 'AWAY'     ? '<span class="status-dot dot-pending"></span>Away'
          : '<span class="status-dot dot-cancelled"></span>Disabled';

        // Photo cell
        const photoHtml = u.profileImage
          ? '<img src="' + u.profileImage + '" style="width:36px;height:36px;border-radius:50%;object-fit:cover;" />'
          : '<div style="width:36px;height:36px;border-radius:50%;background:#e0e0e0;display:flex;align-items:center;justify-content:center;"><i class="ti ti-user" style="font-size:18px;color:#aaa;"></i></div>';

        let actionCell = '<td></td>';
        if (canMgr && String(u.id) !== myId) {
          actionCell = '<td style="white-space:nowrap;">'
            + '<button class="btn btn-primary btn-sm" onclick="askEditEmployee(' + u.id + ')" style="margin-right:4px;" title="Edit"><i class="ti ti-edit"></i> Edit</button>'
            + (u.status === 'ACTIVE'
              ? '<button class="btn btn-warning btn-sm" onclick="setUserStatus(' + u.id + ', \'DISABLED\')"><i class="ti ti-ban"></i> Disable</button>'
              : '<button class="btn btn-success btn-sm" onclick="setUserStatus(' + u.id + ', \'ACTIVE\')"><i class="ti ti-check"></i> Enable</button>')
            + '</td>';
        }

        return '<tr>'
          + '<td>' + photoHtml + '</td>'
          + '<td>' + escapeHtml(u.employeeId || '—') + '</td>'
          + '<td><strong>' + escapeHtml(u.fullName) + (String(u.id) === myId ? ' <span style="font-size:10px;color:#999;">(you)</span>' : '') + '</strong></td>'
          + '<td>' + escapeHtml(u.designation || '—') + '</td>'
          + '<td>' + escapeHtml(u.contactNumber || '—') + '</td>'
          + '<td>' + escapeHtml(u.email) + '</td>'
          + '<td>' + roleBadge(u.role) + '</td>'
          + '<td>' + statusDot + '</td>'
          + actionCell
          + '</tr>';
      }).join('');
    } catch (err) {
      tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#999;">Connection error</td></tr>';
    }
  }

  // ----------------------------------------------------------------
  // Profile image preview helper (shared by Add and Edit modals)
  // ----------------------------------------------------------------
  window.previewEmpImage = function (input, previewId) {
    const preview = $(previewId);
    if (!preview || !input.files || !input.files[0]) return;
    const reader = new FileReader();
    reader.onload = function (e) {
      preview.innerHTML = '<img src="' + e.target.result + '" style="width:100%;height:100%;object-fit:cover;" />';
      // Store base64 on the input element for later retrieval
      input._base64 = e.target.result;
    };
    reader.readAsDataURL(input.files[0]);
  };

  window.askAddEmployee = function () {
    if (!canManageEmployees()) { showToast('Administrator access required', 'error'); return; }
    // Clear all fields
    ['add-emp-name','add-emp-empid','add-emp-email','add-emp-username',
     'add-emp-password','add-emp-designation','add-emp-contact','add-emp-birthdate','add-emp-address']
      .forEach(function (id) { if ($(id)) $(id).value = ''; });
    if ($('add-emp-role')) $('add-emp-role').value = 'STANDARD_USER';
    // Reset image preview
    const prev = $('add-emp-img-preview');
    if (prev) prev.innerHTML = '<i class="ti ti-user" style="font-size:32px;color:#bbb;"></i>';
    const imgInput = $('add-emp-image');
    if (imgInput) { imgInput.value = ''; imgInput._base64 = null; }
    $('modal-add-employee').classList.add('open');
  };

  window.submitAddEmployee = async function () {
    const fullName = (($('add-emp-name')      || {}).value || '').trim();
    const email    = (($('add-emp-email')     || {}).value || '').trim();
    const password = (($('add-emp-password')  || {}).value || '').trim();
    const role     = ($('add-emp-role')       || {}).value || 'STANDARD_USER';

    if (!fullName) { showToast('Employee name is required', 'error'); return; }
    if (!email)    { showToast('Email is required', 'error'); return; }
    if (!password || password.length < 6) { showToast('Password must be at least 6 characters', 'error'); return; }

    const imgInput = $('add-emp-image');

    // Collect page access checkboxes
    const addPages = [];
    document.querySelectorAll('#add-emp-page-access input[type=checkbox]:checked').forEach(function (cb) {
      addPages.push(cb.value);
    });

    const payload = {
      fullName,
      email,
      password,
      role,
      employeeId:    (($('add-emp-empid')       || {}).value || '').trim(),
      username:      (($('add-emp-username')     || {}).value || '').trim(),
      designation:   (($('add-emp-designation')  || {}).value || '').trim(),
      contactNumber: (($('add-emp-contact')      || {}).value || '').trim(),
      birthdate:     (($('add-emp-birthdate')    || {}).value || '').trim(),
      address:       (($('add-emp-address')      || {}).value || '').trim(),
      profileImage:  (imgInput && imgInput._base64) ? imgInput._base64 : '',
      createdByName: currentUserName(),
      allowedPages:  JSON.stringify(addPages)
    };

    try {
      const res = await fetch('' + API_BASE + '/api/users', {
        method: 'POST', headers: authHeaders(),
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (res.ok) {
        closeModal('modal-add-employee');
        showToast('Account created for ' + fullName, 'success');
        renderUsers();
      } else {
        showToast('Error: ' + (data.message || 'Failed to create account'), 'error');
      }
    } catch (err) {
      showToast('Connection error', 'error');
    }
  };

  // ----------------------------------------------------------------
  // Edit Employee
  // ----------------------------------------------------------------
  window.askEditEmployee = async function (userId) {
    if (!canManageEmployees()) { showToast('Administrator access required', 'error'); return; }
    // Fetch fresh user data
    try {
      const res = await fetch('' + API_BASE + '/api/users/' + userId, { headers: { 'Authorization': 'Bearer ' + sessionStorage.getItem('rrbm_token') } });
      if (!res.ok) { showToast('Failed to load employee data', 'error'); return; }
      const u = await res.json();

      $('edit-emp-id').value          = u.id;
      $('edit-emp-name').value        = u.fullName    || '';
      $('edit-emp-empid').value       = u.employeeId  || '';
      $('edit-emp-email').value       = u.email       || '';
      $('edit-emp-username').value    = u.username    || '';
      $('edit-emp-password').value    = '';
      $('edit-emp-role').value        = u.role        || 'STANDARD_USER';
      $('edit-emp-designation').value = u.designation || '';
      $('edit-emp-contact').value     = u.contactNumber || '';
      $('edit-emp-birthdate').value   = u.birthdate   || '';
      $('edit-emp-address').value     = u.address     || '';

      // Profile image preview
      const prev     = $('edit-emp-img-preview');
      const imgInput = $('edit-emp-image');
      if (imgInput) { imgInput.value = ''; imgInput._base64 = null; }
      if (prev) {
        prev.innerHTML = u.profileImage
          ? '<img src="' + u.profileImage + '" style="width:100%;height:100%;object-fit:cover;" />'
          : '<i class="ti ti-user" style="font-size:32px;color:#bbb;"></i>';
      }

      // Populate page access checkboxes
      let allowedPages = [];
      try { allowedPages = u.allowedPages ? JSON.parse(u.allowedPages) : null; } catch (e) {}
      // null = all pages; array = specific pages
      document.querySelectorAll('#edit-emp-page-access input[type=checkbox]').forEach(function (cb) {
        cb.checked = (allowedPages === null) || allowedPages.includes(cb.value);
      });
      // Only Super Admin can edit page access — disable for others
      const editPageAccess = $('edit-emp-page-access');
      if (editPageAccess) {
        const disabled = !isSuperAdmin();
        editPageAccess.querySelectorAll('input').forEach(function (cb) { cb.disabled = disabled; });
        editPageAccess.style.opacity = disabled ? '0.5' : '1';
      }

      $('modal-edit-employee').classList.add('open');
    } catch (err) {
      showToast('Connection error', 'error');
    }
  };

  window.submitEditEmployee = async function () {
    const userId   = ($('edit-emp-id')   || {}).value;
    const fullName = (($('edit-emp-name') || {}).value || '').trim();
    const email    = (($('edit-emp-email')|| {}).value || '').trim();
    if (!userId)   { showToast('Missing employee ID', 'error'); return; }
    if (!fullName) { showToast('Employee name is required', 'error'); return; }
    if (!email)    { showToast('Email is required', 'error'); return; }

    const newPassword  = (($('edit-emp-password') || {}).value || '').trim();
    if (newPassword && newPassword.length < 6) { showToast('Password must be at least 6 characters', 'error'); return; }

    const imgInput = $('edit-emp-image');
    const payload = {
      fullName,
      email,
      employeeId:    (($('edit-emp-empid')       || {}).value || '').trim(),
      username:      (($('edit-emp-username')     || {}).value || '').trim(),
      role:          ($('edit-emp-role')          || {}).value || 'STANDARD_USER',
      designation:   (($('edit-emp-designation')  || {}).value || '').trim(),
      contactNumber: (($('edit-emp-contact')      || {}).value || '').trim(),
      birthdate:     (($('edit-emp-birthdate')    || {}).value || '').trim(),
      address:       (($('edit-emp-address')      || {}).value || '').trim(),
      changedByName: currentUserName()
    };
    // Only include password if provided
    if (newPassword) payload.password = newPassword;
    // Only include new image if one was selected
    if (imgInput && imgInput._base64) payload.profileImage = imgInput._base64;

    try {
      const res = await fetch('' + API_BASE + '/api/users/' + userId, {
        method: 'PUT', headers: authHeaders(),
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (res.ok) {
        // If Super Admin, also save page permissions
        if (isSuperAdmin()) {
          const editPages = [];
          document.querySelectorAll('#edit-emp-page-access input[type=checkbox]:checked').forEach(function (cb) {
            editPages.push(cb.value);
          });
          await fetch(API_BASE + '/api/users/' + userId + '/permissions', {
            method: 'PATCH', headers: authHeaders(),
            body: JSON.stringify({ allowedPages: JSON.stringify(editPages), changedByName: currentUserName() })
          });
        }
        closeModal('modal-edit-employee');
        showToast('Employee profile updated', 'success');
        renderUsers();
      } else {
        showToast('Error: ' + (data.message || 'Failed to update profile'), 'error');
      }
    } catch (err) {
      showToast('Connection error', 'error');
    }
  };

  window.askAssignRole = function (userId, userName, currentRole) {
    if (!canManageEmployees()) { showToast('Administrator access required', 'error'); return; }
    $('assign-role-user-id').value = userId;
    $('assign-role-user-name').textContent = userName;
    if ($('assign-role-select')) $('assign-role-select').value = currentRole;
    $('modal-assign-role').classList.add('open');
  };

  window.confirmAssignRole = async function () {
    const userId  = ($('assign-role-user-id')  || {}).value;
    const newRole = ($('assign-role-select')   || {}).value;
    if (!userId || !newRole) { showToast('Missing data', 'error'); return; }

    try {
      const res = await fetch('' + API_BASE + '/api/users/' + userId + '/role', {
        method: 'PATCH', headers: authHeaders(),
        body: JSON.stringify({ role: newRole, changedByName: currentUserName() })
      });
      const data = await res.json();
      if (res.ok) {
        closeModal('modal-assign-role');
        showToast('Role updated successfully', 'success');
        renderUsers();
      } else {
        showToast('Error: ' + (data.message || 'Failed to update role'), 'error');
      }
    } catch (err) {
      showToast('Connection error', 'error');
    }
  };

  window.setUserStatus = async function (userId, newStatus) {
    if (!canManageEmployees()) { showToast('Administrator access required', 'error'); return; }
    try {
      const res = await fetch('' + API_BASE + '/api/users/' + userId + '/status', {
        method: 'PATCH', headers: authHeaders(),
        body: JSON.stringify({ status: newStatus, changedByName: currentUserName() })
      });
      if (res.ok) {
        showToast('User status updated to ' + newStatus, 'success');
        renderUsers();
      } else {
        const d = await res.json();
        showToast('Error: ' + (d.message || 'Failed'), 'error');
      }
    } catch (err) {
      showToast('Connection error', 'error');
    }
  };

  // ================================================================
  // CHANGE MASTER KEY (Settings)
  // ================================================================
  window.changeMasterKey = async function () {
    const current = (($('set-current-key') || {}).value || '').trim();
    const newKey  = (($('set-new-key')     || {}).value || '').trim();
    const confirm = (($('set-confirm-key') || {}).value || '').trim();
    if (!current || !newKey) { showToast('All fields are required', 'error'); return; }
    if (newKey !== confirm)  { showToast('New keys do not match', 'error'); return; }
    if (newKey.length < 6)   { showToast('New master key must be at least 6 characters', 'error'); return; }
    try {
      const res = await fetch('' + API_BASE + '/api/auth/master-key', {
        method: 'POST', headers: authHeaders(),
        body: JSON.stringify({ currentKey: current, newKey: newKey })
      });
      if (res.ok) {
        showToast('Master key updated successfully', 'success');
        if ($('set-current-key')) $('set-current-key').value = '';
        if ($('set-new-key'))     $('set-new-key').value = '';
        if ($('set-confirm-key')) $('set-confirm-key').value = '';
      } else {
        const d = await res.json();
        showToast('Error: ' + (d.message || 'Failed to update'), 'error');
      }
    } catch (err) {
      showToast('Connection error', 'error');
    }
  };

  // ================================================================
  // Navigation — settings restriction, form state, order-history
  // ================================================================
  window.navigateTo = function (view) {
    // Block Settings for non-Super-Admins
    if (view === 'set' && !isSuperAdmin()) {
      showToast('Settings is restricted to Super Admin only', 'error');
      return;
    }
    // Block Employee List for non-managers
    if (view === 'emp' && !canManageEmployees()) {
      showToast('Employee List is restricted to Administrators and above', 'error');
      return;
    }
    // Block pages not in user's allowedPages
    if (!canAccessPage(view)) {
      showToast('You do not have access to this page', 'error');
      return;
    }

    $$('.nav-item').forEach(function (n) { n.classList.toggle('active', n.dataset.view === view); });
    $$('.view').forEach(function (w) { w.classList.remove('active'); });
    const target = $('view-' + view);
    if (target) target.classList.add('active');

    const titles = {
      dash:           ['Dashboard',        "Today's overview"],
      new:            ['New Order',         'Create an order'],
      list:           ['Order List',        "Today's orders"],
      inv:            ['Inventory',         'Stock levels'],
      delivery:       ['Receive Stock',     'Delivery receipt & stock in'],
      rep:            ['Reports',           'Analytics & insights'],
      'order-history':['Order History',     'Search and export past orders'],
      'delivery-rep': ['Delivery Reports',  'Received stock history'],
      'activity-log': ['Activity Log',      'Admin action history'],
      emp:            ['Employee List',      'Manage employees'],
      expenses:       ['Expenses',           'Daily expense tracking'],
      set:            ['Settings',          'System configuration'],
    };
    if (titles[view]) {
      $('page-title').textContent  = titles[view][0];
      $('page-subtitle').textContent = titles[view][1];
    }

    if (view === 'new') {
      if (!appState.orderFormReady) { initOrderForm(); }
      else { loadProducts(); }
      renderOrders();
    }
    if (view === 'list')     renderOrderList();
    if (view === 'inv')      renderInventory();
    if (view === 'delivery') {
      if (!appState.deliveryFormReady) { initDeliveryForm(); }
      else {
        loadProducts();
        const encEl = $('delivery-encoded-by');
        if (encEl) encEl.value = currentUserName();
      }
    }
    if (view === 'rep')           setTimeout(initReportsView, 50);
    if (view === 'order-history') {
      if ($('history-start') && !$('history-start').value) {
        const d30 = new Date(); d30.setDate(d30.getDate() - 30);
        $('history-start').value = d30.toISOString().split('T')[0];
      }
      if ($('history-end') && !$('history-end').value) {
        const yest = new Date(); yest.setDate(yest.getDate() - 1);
        $('history-end').value = yest.toISOString().split('T')[0];
      }
      renderOrderHistory();
    }
    if (view === 'delivery-rep') renderDeliveryReports(true);
    if (view === 'activity-log') renderActivityLog(true);
    if (view === 'expenses')     initExpensesView();
    if (view === 'emp')          renderUsers();
    if (view === 'dash')         { renderDashboard(); renderTopProductsToday(); }
    if (view === 'set')          loadSettings();
  };

  // ================================================================
  // Theme Toggle
  // ================================================================
  window.toggleTheme = function () {
    appState.theme = appState.theme === 'light' ? 'dark' : 'light';
    document.body.dataset.theme = appState.theme;
    const icon = $('theme-icon');
    if (icon) icon.className = appState.theme === 'light' ? 'ti ti-sun' : 'ti ti-moon';
  };

  // ================================================================
  // NEW ORDER FORM — form state, new fields
  // ================================================================
  async function loadProducts() {
    try {
      const res = await fetch('' + API_BASE + '/api/products', {
        headers: { 'Authorization': 'Bearer ' + sessionStorage.getItem('rrbm_token') }
      });
      if (res.ok) { appState.cachedProducts = await res.json(); }
      else { appState.cachedProducts = []; }
    } catch (e) { appState.cachedProducts = []; }
  }

  window.onSourceChange = function () {
    const v = $('field-source').value;
    const agentWrap    = $('field-agent-wrap');
    const resellerWrap = $('field-reseller-wrap');
    const fbWrap       = $('field-fb-wrap');
    const ecomWrap     = $('ecommercePlatformGroup');
    const resellerLbl  = $('label-reseller');

    if (agentWrap)    agentWrap.style.display    = (v === 'AGENT')        ? '' : 'none';
    if (resellerWrap) resellerWrap.style.display = (v === 'RESELLER' || v === 'DISTRIBUTOR') ? '' : 'none';
    if (fbWrap)       fbWrap.style.display       = (v === 'FACEBOOK_PAGE') ? '' : 'none';
    if (ecomWrap) {
      ecomWrap.style.display = (v === 'ECOMMERCE') ? '' : 'none';
      if (v !== 'ECOMMERCE' && $('ecommercePlatform')) $('ecommercePlatform').value = '';
    }
    // Update label based on source
    if (resellerLbl) resellerLbl.textContent = v === 'DISTRIBUTOR' ? 'Distributor Name' : 'Reseller Name';
  };

  async function initOrderForm(forceReset) {
    await loadProducts();
    if (!forceReset && appState.orderFormReady) return;

    const container = $('orderItemsContainer'); if (!container) return;
    container.innerHTML = ''; appState.itemRowCounter = 0; addItemRow();
    const addBtn = $('addItemBtn');
    if (addBtn) { const fresh = addBtn.cloneNode(true); addBtn.parentNode.replaceChild(fresh, addBtn); fresh.addEventListener('click', addItemRow); }
    const disc = $('orderDiscount');
    if (disc) { disc.removeEventListener('input', calculateOrderTotals); disc.addEventListener('input', calculateOrderTotals); }
    calculateOrderTotals();
    appState.orderFormReady = true;
  }

  function addItemRow() {
    appState.itemRowCounter++;
    const num = appState.itemRowCounter;
    const rowId = 'item-row-' + num;
    const container = $('orderItemsContainer'); if (!container) return;
    container.insertAdjacentHTML('beforeend', '<div class="order-item-row" id="' + rowId + '"><div class="row align-items-end">'
      + '<div class="col-md-4"><label class="form-label">Product <span class="text-danger">*</span></label><div class="product-autocomplete-wrapper"><input type="text" class="form-control product-input" id="productInput-' + num + '" placeholder="Type to search products..." autocomplete="off" required><input type="hidden" class="product-id-hidden" id="productId-' + num + '" value=""><input type="hidden" id="warehouse-' + num + '" value="wh1"><div class="product-dropdown" id="productDropdown-' + num + '"></div></div></div>'
      + '<div class="col-md-2"><label class="form-label">Qty <span class="text-danger">*</span></label><input type="number" class="form-control item-quantity" id="quantity-' + num + '" min="1" value="1" required></div>'
      + '<div class="col-md-2"><label class="form-label">Unit Price (₱) <span class="text-danger">*</span></label><input type="number" class="form-control item-unit-price" id="unitPrice-' + num + '" min="0" step="0.01" value="0" required></div>'
      + '<div class="col-md-2"><label class="form-label">Stock Info</label><div class="stock-info-display" id="stockInfo-' + num + '" style="font-size:11px;padding:6px 8px;background:#f0f0f0;border-radius:6px;min-height:34px;display:flex;align-items:center;color:#666;">Select a product</div></div>'
      + '<div class="col-md-1"><label class="form-label">Subtotal</label><input type="text" class="form-control item-subtotal" id="subtotal-' + num + '" value="₱0.00" readonly style="background-color:#e9ecef;font-size:12px;"></div>'
      + '<div class="col-md-1 text-center"><label class="form-label">&nbsp;</label><button type="button" class="remove-item-btn d-block" onclick="removeItemRow(\'' + rowId + '\')"><i class="ti ti-trash"></i></button></div>'
      + '</div></div>');
    setupProductAutocomplete(num);
    const q = $('quantity-' + num); if (q) q.addEventListener('input', function () { calcItemSubtotal(num); });
    const p = $('unitPrice-' + num); if (p) p.addEventListener('input', function () { calcItemSubtotal(num); });
  }

  window.removeItemRow = function (rowId) { const row = $(rowId); if (row) { row.remove(); calculateOrderTotals(); } };

  function setupProductAutocomplete(rowNum) {
    const input = $('productInput-' + rowNum); const dropdown = $('productDropdown-' + rowNum);
    if (!input || !dropdown) return;
    input.addEventListener('input', function () { const t = this.value.toLowerCase().trim(); renderProductDropdown(dropdown, t.length === 0 ? appState.cachedProducts : appState.cachedProducts.filter(function (p) { return p.name.toLowerCase().includes(t); }), rowNum); });
    input.addEventListener('focus', function () { const t = this.value.toLowerCase().trim(); renderProductDropdown(dropdown, t.length === 0 ? appState.cachedProducts : appState.cachedProducts.filter(function (p) { return p.name.toLowerCase().includes(t); }), rowNum); });
    document.addEventListener('click', function (e) { if (!input.contains(e.target) && !dropdown.contains(e.target)) dropdown.classList.remove('show'); });
  }

  function renderProductDropdown(dropdown, products, rowNum) {
    if (products.length === 0) { dropdown.innerHTML = '<div class="product-dropdown-item" style="color:#999;cursor:default;">No products found</div>'; dropdown.classList.add('show'); return; }
    let html = '';
    products.forEach(function (product) {
      const wh1 = product.stockWh1 || 0, wh2 = product.stockWh2 || 0, wh3 = product.stockWh3 || 0, total = wh1 + wh2 + wh3;
      let stockClass = 'ok', stockLabel = total.toLocaleString() + ' pcs';
      if (total <= 0) { stockClass = 'critical'; stockLabel = 'Out of stock'; }
      else if (total <= (product.thresholdCritical || 0)) { stockClass = 'critical'; stockLabel = total.toLocaleString() + ' (critical)'; }
      else if (total <= (product.thresholdLow || 0)) { stockClass = 'low'; stockLabel = total.toLocaleString() + ' (low)'; }
      let whParts = []; if (wh1 > 0) whParts.push('WH1:' + wh1.toLocaleString()); if (wh2 > 0) whParts.push('WH2:' + wh2.toLocaleString()); if (wh3 > 0) whParts.push('WH3:' + wh3.toLocaleString());
      let primaryWh = 'wh1'; if (wh2 > wh1 && wh2 >= wh3) primaryWh = 'wh2'; if (wh3 > wh1 && wh3 > wh2) primaryWh = 'wh3';
      html += '<div class="product-dropdown-item" data-id="' + product.id + '" data-name="' + escapeHtml(product.name) + '" data-price="' + product.unitPrice + '" data-wh="' + primaryWh + '" data-wh1="' + wh1 + '" data-wh2="' + wh2 + '" data-wh3="' + wh3 + '" data-row="' + rowNum + '"><div style="flex:1;"><div class="product-name">' + product.name + '</div><div style="font-size:10px;color:#888;">' + (whParts.join(' · ') || 'No stock') + '</div></div><div style="text-align:right;"><span class="product-price">₱' + parseFloat(product.unitPrice).toFixed(2) + '</span><br><span class="product-stock ' + stockClass + '">' + stockLabel + '</span></div></div>';
    });
    dropdown.innerHTML = html; dropdown.classList.add('show');
    dropdown.querySelectorAll('.product-dropdown-item[data-id]').forEach(function (item) {
      item.addEventListener('click', function () {
        const rn = this.getAttribute('data-row'), wh1 = parseInt(this.getAttribute('data-wh1')) || 0, wh2 = parseInt(this.getAttribute('data-wh2')) || 0, wh3 = parseInt(this.getAttribute('data-wh3')) || 0, pw = this.getAttribute('data-wh');
        $('productInput-' + rn).value = this.getAttribute('data-name');
        $('productId-' + rn).value = this.getAttribute('data-id');
        $('unitPrice-' + rn).value = parseFloat(this.getAttribute('data-price')).toFixed(2);
        $('warehouse-' + rn).value = pw;
        const si = $('stockInfo-' + rn);
        if (si) { let pts = []; if (wh1 > 0) pts.push('<span style="color:' + (pw === 'wh1' ? '#10B981;font-weight:600' : '#666') + '">WH1: ' + wh1.toLocaleString() + '</span>'); if (wh2 > 0) pts.push('<span style="color:' + (pw === 'wh2' ? '#10B981;font-weight:600' : '#666') + '">WH2: ' + wh2.toLocaleString() + '</span>'); if (wh3 > 0) pts.push('<span style="color:' + (pw === 'wh3' ? '#10B981;font-weight:600' : '#666') + '">WH3: ' + wh3.toLocaleString() + '</span>'); si.innerHTML = pts.length > 0 ? '📦 ' + pts.join(' · ') : '<span style="color:#EF4444;">No stock</span>'; }
        dropdown.classList.remove('show'); calcItemSubtotal(rn);
      });
    });
  }

  function calcItemSubtotal(rn) {
    const q = parseFloat(($('quantity-' + rn) || {}).value) || 0, p = parseFloat(($('unitPrice-' + rn) || {}).value) || 0;
    const el = $('subtotal-' + rn); if (el) el.value = '₱' + (q * p).toFixed(2);
    calculateOrderTotals();
  }

  function calculateOrderTotals() {
    let sub = 0; $$('.item-subtotal').forEach(function (i) { sub += parseFloat(i.value.replace('₱', '')) || 0; });
    const disc = parseFloat(($('orderDiscount') || {}).value) || 0;
    if ($('orderSubtotal'))       $('orderSubtotal').textContent       = '₱' + sub.toFixed(2);
    if ($('orderDiscountAmount')) $('orderDiscountAmount').textContent  = '-₱' + disc.toFixed(2);
    if ($('orderTotal'))          $('orderTotal').textContent           = '₱' + (sub - disc).toFixed(2);
  }

  // ================================================================
  // Submit Order
  // ================================================================
  window.addOrder = async function () {
    const customerName = (($('field-customer')  || {}).value || '').trim();
    const source       = ($('field-source')     || {}).value;
    const agentName    = ($('field-agent')      || {}).value || '';
    const resellerName = ($('field-reseller')   || {}).value || '';
    const fbPage       = ($('field-fb')         || {}).value || '';
    const paymentMode  = ($('field-payment')    || {}).value;
    const orderType    = ($('field-order-type') || {}).value || 'STANDARD';
    const address      = ($('field-address')    || {}).value || '';
    const discount     = parseFloat(($('orderDiscount') || {}).value) || 0;
    const notes        = ($('orderNotes') || {}).value || '';

    if (!customerName) { showToast('Please enter customer name', 'error'); return; }
    if (!source)       { showToast('Please select order source', 'error'); return; }
    if (!paymentMode)  { showToast('Please select payment mode', 'error'); return; }

    let ecommercePlatform = null;
    if (source === 'ECOMMERCE') {
      ecommercePlatform = ($('ecommercePlatform') || {}).value;
      if (!ecommercePlatform) { showToast('Please select an e-commerce platform', 'error'); return; }
    }

    // Determine named contact based on source
    let contactName = null;
    if (source === 'AGENT') contactName = agentName;
    else if (source === 'RESELLER' || source === 'DISTRIBUTOR') contactName = resellerName;

    const itemRows = $$('.order-item-row');
    if (itemRows.length === 0) { showToast('Please add at least one item', 'error'); return; }

    const items = []; let hasError = false;
    itemRows.forEach(function (row) {
      if (hasError) return;
      const rn        = row.id.replace('item-row-', '');
      const productName = ($('productInput-' + rn) || {}).value || '';
      const productId = ($('productId-' + rn) || {}).value || '';
      const quantity  = parseInt(($('quantity-' + rn) || {}).value) || 0;
      const unitPrice = parseFloat(($('unitPrice-' + rn) || {}).value) || 0;
      const warehouse = ($('warehouse-' + rn) || {}).value || 'wh1';
      if (!productName.trim()) { showToast('Please select a product for all items', 'error'); hasError = true; return; }
      if (quantity <= 0)       { showToast('Quantity must be at least 1 for ' + productName, 'error'); hasError = true; return; }
      if (unitPrice <= 0)      { showToast('Unit price must be greater than 0 for ' + productName, 'error'); hasError = true; return; }
      const item = { productName: productName.trim(), quantity, unitPrice, warehouse };
      if (productId && productId !== '') item.productId = parseInt(productId);
      items.push(item);
    });
    if (hasError) return;

    const orderRequest = {
      customerName, source,
      agentName:        contactName || null,
      fbPage:           source === 'FACEBOOK_PAGE' ? fbPage : null,
      ecommercePlatform,
      paymentMode, orderType,
      address:          address || null,
      discount, notes, items
    };

    try {
      const token = sessionStorage.getItem('rrbm_token');
      if (!token) { showToast('Please login first', 'error'); return; }
      const res = await fetch('' + API_BASE + '/api/orders', { method: 'POST', headers: authHeaders(), body: JSON.stringify(orderRequest) });
      if (!res.ok) { let msg = 'Failed to create order'; try { const d = await res.json(); msg = d.message || d.error || msg; } catch (e) {} showToast('Error: ' + msg, 'error'); return; }
      const created = await res.json();
      showToast('Order created: ' + created.id, 'success');
      clearOrderForm();
      renderOrders();
    } catch (err) {
      showToast('Connection error. Is the backend running?', 'error');
    }
  };

  function clearOrderForm() {
    if ($('field-customer'))         $('field-customer').value = '';
    if ($('field-source'))           $('field-source').value = '';
    if ($('field-agent'))            $('field-agent').value = '';
    if ($('field-reseller'))         $('field-reseller').value = '';
    if ($('field-fb'))               $('field-fb').value = '';
    if ($('field-payment'))          $('field-payment').value = '';
    if ($('field-order-type'))       $('field-order-type').value = 'STANDARD';
    if ($('field-address'))          $('field-address').value = '';
    if ($('orderDiscount'))          $('orderDiscount').value = '0';
    if ($('orderNotes'))             $('orderNotes').value = '';
    if ($('field-agent-wrap'))       $('field-agent-wrap').style.display = 'none';
    if ($('field-reseller-wrap'))    $('field-reseller-wrap').style.display = 'none';
    if ($('field-fb-wrap'))          $('field-fb-wrap').style.display = 'none';
    if ($('ecommercePlatformGroup')) $('ecommercePlatformGroup').style.display = 'none';
    if ($('ecommercePlatform'))      $('ecommercePlatform').value = '';
    const c = $('orderItemsContainer'); if (c) { c.innerHTML = ''; appState.itemRowCounter = 0; addItemRow(); }
    calculateOrderTotals();
  }
  window.clearOrderForm = clearOrderForm;

  // ================================================================
  // Cancel Order — master key protected
  // ================================================================
  window.askCancel = function (id) {
    appState.cancelTargetId = id;
    $('cancel-order-id').textContent = id;
    $('cancel-reason-input').value = '';
    $('cancel-key-input').value = '';
    $('modal-cancel').classList.add('open');
  };

  window.confirmCancel = async function () {
    const reason = ($('cancel-reason-input').value || '').trim();
    const key    = ($('cancel-key-input').value || '').trim();
    if (!reason) { showToast('Cancellation reason is required', 'error'); return; }
    if (!key)    { showToast('Master key is required', 'error'); return; }
    try {
      const res = await fetch('' + API_BASE + '/api/orders/' + appState.cancelTargetId + '/cancel', {
        method: 'POST', headers: authHeaders(),
        body: JSON.stringify({ masterKey: key, reason: reason })
      });
      if (res.ok) {
        closeModal('modal-cancel');
        showToast('Order ' + appState.cancelTargetId + ' cancelled', 'success');
        renderOrderList(); renderOrders();
      } else {
        const err = await res.json();
        showToast('Error: ' + (err.message || 'Failed to cancel'), 'error');
      }
    } catch (error) {
      showToast('Connection error', 'error');
    }
  };

  // ================================================================
  // Login
  // ================================================================
  window.doLogin = async function () {
    const email = $('login-email').value, password = $('login-password').value;
    if (!email || !password) { showToast('Please enter email and password', 'error'); return; }
    try {
      const res = await fetch('' + API_BASE + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
      if (!res.ok) { const err = await res.json(); showToast(err.message || 'Invalid credentials', 'error'); return; }
      const { token, user } = await res.json();
      sessionStorage.setItem('rrbm_token', token);
      sessionStorage.setItem('rrbm_user', JSON.stringify(user));

      const av = $('sidebar-avatar'), un = $('sidebar-name'), ur = $('sidebar-role');
      if (av && user.fullName) av.textContent = user.fullName.split(' ').map(function (n) { return n[0]; }).join('').slice(0, 2).toUpperCase();
      if (un) un.textContent = user.fullName;
      if (ur && user.role) ur.textContent = user.role.replace(/_/g, ' ');

      // Apply role-based restrictions + page access nav hiding
      applyRoleRestrictions(user.role);
      applyPageAccessToNav();

      $('login-screen').style.display = 'none';
      showToast('Welcome, ' + user.fullName + '!', 'success');

      // Load live dashboard data immediately after login
      renderDashboard();
      renderTopProductsToday();
    } catch (err) {
      showToast('Connection error. Is the backend running?', 'error');
    }
  };

  // ================================================================
  // Toast Notifications
  // ================================================================
  window.showToast = function (msg, type) {
    type = type || ''; const id = 'toast-' + (appState.toastId++);
    const el = document.createElement('div'); el.className = 'rrbm-toast ' + type; el.id = id;
    const icon = type === 'success' ? 'check' : type === 'error' ? 'alert-circle' : 'info-circle';
    el.innerHTML = '<i class="ti ti-' + icon + '"></i><span>' + msg + '</span>';
    const c = $('rrbm-toast-container'); if (c) c.appendChild(el);
    setTimeout(function () { const t = $(id); if (t) t.remove(); }, 3500);
  };

  // ================================================================
  // Live Clock
  // ================================================================
  function updateClock() {
    const d = new Date(); const el = $('clock');
    if (el) el.textContent = pad(d.getHours(), 2) + ':' + pad(d.getMinutes(), 2) + ':' + pad(d.getSeconds(), 2);
  }

  // ================================================================
  // Charts — Dashboard (initialise empty; renderDashboard fills them)
  // ================================================================
  function initDashboardCharts() {
    if (typeof Chart === 'undefined') { setTimeout(initDashboardCharts, 100); return; }

    const c1 = $('chart-sales');
    if (c1 && !c1.dataset.init) {
      c1.dataset.init = '1';
      appState.chartSales = new Chart(c1, {
        type: 'bar',
        data: {
          labels: ['','','','','','',''],
          datasets: [{ label: 'Sales (₱)', data: [0,0,0,0,0,0,0],
            backgroundColor: 'rgba(212,134,10,0.75)', borderRadius: 4 }]
        },
        options: {
          responsive: true, maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: { ticks: { callback: function(v) { return '₱' + (v/1000).toFixed(0) + 'k'; }, font: { size: 10 } } },
            x: { ticks: { font: { size: 10 } } }
          }
        }
      });
    }

    const c2 = $('chart-ecommerce');
    if (c2 && !c2.dataset.init) {
      c2.dataset.init = '1';
      appState.chartPayment = new Chart(c2, {
        type: 'doughnut',
        data: { labels: [], datasets: [{ data: [], backgroundColor: [] }] },
        options: {
          responsive: true, maintainAspectRatio: false,
          plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } } }
        }
      });
    }
  }

  // ================================================================
  // Dashboard — tab switching
  // ================================================================
  appState.dashPeriod = 'daily';

  window.switchDashTab = function (period) {
    appState.dashPeriod = period;
    ['daily', 'weekly', 'monthly'].forEach(function (p) {
      const btn = $('dash-tab-' + p);
      if (btn) btn.classList.toggle('active', p === period);
    });
    renderDashboard(period);
    renderTopProductsToday();
  };

  // ================================================================
  // Dashboard — fetch live stats and update all cards + charts
  // ================================================================
  async function renderDashboard(period) {
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) return;
    period = period || appState.dashPeriod || 'daily';

    try {
      const res = await fetch(API_BASE + '/api/dashboard/stats?period=' + period,
        { headers: { 'Authorization': 'Bearer ' + token } });
      if (!res.ok) return;
      const s = await res.json();

      // ── Stat card labels (update for period) ─────────────────────
      const periodLabel = period === 'weekly' ? 'This Week' : period === 'monthly' ? 'This Month' : 'Today';
      const fmt = function(n) { return '₱' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };

      setText('stat-sales-label',    'Total Sales ' + periodLabel);
      setText('stat-cancelled-label','Cancelled ' + periodLabel);

      if ($('stat-total-sales'))    $('stat-total-sales').textContent    = fmt(s.totalSales || 0);
      if ($('stat-order-count'))    $('stat-order-count').textContent    = (s.orderCount || 0) + ' orders ' + periodLabel.toLowerCase();
      if ($('stat-active-orders'))  $('stat-active-orders').textContent  = s.activeOrders || 0;
      if ($('stat-pending-orders')) $('stat-pending-orders').textContent = (s.pendingOrders || 0) + ' pending';
      if ($('stat-cancelled'))      $('stat-cancelled').textContent      = s.cancelledOrders || 0;
      if ($('stat-low-stock'))      $('stat-low-stock').textContent      = s.lowStockCount || 0;

      // ── Pizza Box Quota Tracker ───────────────────────────────────
      const PIZZA_QUOTA = 5000;
      const pizzaQty    = s.pizzaBoxQtyToday || 0;
      const pct         = Math.min(Math.round((pizzaQty / PIZZA_QUOTA) * 100), 100);
      const bar         = $('pizza-progress-bar');
      const card        = $('pizza-quota-card');
      const barColor    = pizzaQty >= PIZZA_QUOTA ? '#10B981'
                        : pizzaQty >= 2500        ? '#F59E0B'
                        : '#EF4444';

      setText('pizza-qty-display', pizzaQty.toLocaleString() + ' pcs');
      setText('pizza-pct-display', pct + '%');
      if (bar) { bar.style.width = pct + '%'; bar.style.background = barColor; }
      if (card) {
        card.classList.toggle('pizza-quota-met', pizzaQty >= PIZZA_QUOTA);
      }
      const statusMsg = pizzaQty >= PIZZA_QUOTA
          ? '✅ Quota met!'
          : (PIZZA_QUOTA - pizzaQty).toLocaleString() + ' pcs remaining to reach quota';
      setText('pizza-status-text', statusMsg);

      // ── Low stock detail panel ────────────────────────────────────
      const panel = $('low-stock-panel');
      const lsTb  = $('low-stock-tbody');
      const lsCnt = $('low-stock-panel-count');
      if (panel && lsTb) {
        const items = s.lowStockItems || [];
        if (items.length > 0) {
          panel.style.display = '';
          if (lsCnt) lsCnt.textContent = items.length + ' product' + (items.length > 1 ? 's' : '') + ' at or below low threshold';
          lsTb.innerHTML = items.map(function (p) {
            const shortfall = (p.threshold || 0) - (p.stock || 0);
            const tagCls = p.tag === 'HOT' ? 'badge-hot' : p.tag === 'SELLING' ? 'badge-selling' : 'badge-slow';
            return '<tr>'
              + '<td><strong>' + escapeHtml(p.name) + '</strong></td>'
              + '<td><span class="badge ' + tagCls + '">' + (p.tag || '—') + '</span></td>'
              + '<td style="color:#EF4444;font-weight:600;">' + (p.stock || 0).toLocaleString() + ' pcs</td>'
              + '<td>' + (p.threshold || 0).toLocaleString() + ' pcs</td>'
              + '<td style="color:#EF4444;">−' + shortfall.toLocaleString() + ' pcs</td>'
              + '</tr>';
          }).join('');
        } else {
          panel.style.display = 'none';
        }
      }

      // ── Payment breakdown cards ───────────────────────────────────
      const pd = s.paymentBreakdown || {};
      const cashTotal    = (pd['CASH'] || 0);
      const ewalletTotal = (pd['GCASH'] || 0) + (pd['PAYMAYA'] || 0) + (pd['ONLINE'] || 0);
      const codTotal     = (pd['COD'] || 0);
      const bankTotal    = (pd['BANK_TRANSFER'] || 0) + (pd['BANK_DEPOSIT'] || 0);
      if ($('stat-cash'))           $('stat-cash').textContent           = fmt(cashTotal);
      if ($('stat-ewallet'))        $('stat-ewallet').textContent        = fmt(ewalletTotal);
      if ($('stat-cod'))            $('stat-cod').textContent            = fmt(codTotal);
      if ($('stat-bank'))           $('stat-bank').textContent           = fmt(bankTotal);
      if ($('stat-expenses-today')) $('stat-expenses-today').textContent = fmt(s.totalExpensesToday || 0);

      // ── Sales trend chart ─────────────────────────────────────────
      if (appState.chartSales && s.salesTrend) {
        appState.chartSales.data.labels           = s.salesTrend.map(function(d) { return d.label; });
        appState.chartSales.data.datasets[0].data = s.salesTrend.map(function(d) { return Number(d.total) || 0; });
        appState.chartSales.update();
      }

      // ── Payment donut chart ───────────────────────────────────────
      if (appState.chartPayment) {
        const payColors = { CASH:'#10B981', GCASH:'#3B82F6', PAYMAYA:'#8B5CF6',
                            BANK_TRANSFER:'#F59E0B', BANK_DEPOSIT:'#D97706',
                            ONLINE:'#EC4899', COD:'#EF4444' };
        const entries = Object.entries(pd).filter(function(e) { return Number(e[1]) > 0; });
        appState.chartPayment.data.labels                       = entries.map(function(e) { return e[0]; });
        appState.chartPayment.data.datasets[0].data             = entries.map(function(e) { return Number(e[1]); });
        appState.chartPayment.data.datasets[0].backgroundColor  = entries.map(function(e) { return payColors[e[0]] || '#999'; });
        appState.chartPayment.update();
      }

    } catch (err) {
      // Silently ignore — dashboard will show last values
    }
  }

  // ================================================================
  // Dashboard — Top 5 Products Today (FEATURE 5)
  // ================================================================
  window.renderTopProductsToday = async function () {
    const token = sessionStorage.getItem('rrbm_token');
    const tbody = $('top-products-today-tbody');
    if (!token || !tbody) return;
    const fmt = function(n) { return '₱' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    try {
      const res = await fetch(API_BASE + '/api/dashboard/top-products-today',
        { headers: { 'Authorization': 'Bearer ' + token } });
      if (!res.ok) { tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:16px;">Error loading data</td></tr>'; return; }
      const data = await res.json();
      if (!data || data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:16px;">No sales yet today</td></tr>';
        return;
      }
      const medals = ['🥇','🥈','🥉','4','5'];
      tbody.innerHTML = data.map(function (p, i) {
        return '<tr>'
          + '<td style="text-align:center;font-size:15px;">' + (medals[i] || p.rank) + '</td>'
          + '<td style="font-weight:600;">' + escapeHtml(p.name) + '</td>'
          + '<td style="text-align:right;">' + (p.qty || 0).toLocaleString() + ' pcs</td>'
          + '<td style="text-align:right;">' + fmt(p.revenue || 0) + '</td>'
          + '</tr>';
      }).join('');
    } catch (err) {
      tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:16px;">—</td></tr>';
    }
  };

  // ================================================================
  // Settings — load and save company info
  // ================================================================
  async function loadSettings() {
    const token = sessionStorage.getItem('rrbm_token');
    if (!token) return;
    try {
      const res = await fetch('' + API_BASE + '/api/settings',
        { headers: { 'Authorization': 'Bearer ' + token } });
      if (!res.ok) return;
      const data = await res.json();
      if ($('set-company-name'))    $('set-company-name').value    = data['company_name']    || '';
      if ($('set-company-address')) $('set-company-address').value = data['company_address'] || '';
      if ($('set-company-contact')) $('set-company-contact').value = data['company_contact'] || '';
    } catch (err) { /* ignore */ }
  }

  window.saveCompanySettings = async function () {
    const name    = (($('set-company-name')    || {}).value || '').trim();
    const address = (($('set-company-address') || {}).value || '').trim();
    const contact = (($('set-company-contact') || {}).value || '').trim();
    if (!name) { showToast('Company name is required', 'error'); return; }
    try {
      const res = await fetch('' + API_BASE + '/api/settings', {
        method: 'POST', headers: authHeaders(),
        body: JSON.stringify({ company_name: name, company_address: address, company_contact: contact })
      });
      if (res.ok) {
        showToast('Company info saved', 'success');
      } else {
        const d = await res.json();
        showToast('Error: ' + (d.message || 'Failed to save'), 'error');
      }
    } catch (err) { showToast('Connection error', 'error'); }
  };

  // ================================================================
  // Reports — Insights Summary (real data)
  // ================================================================
  function initReportsView() {
    // Set month picker to current month on first open
    const picker = $('rep-month-picker');
    if (picker && !picker.value) {
      const now = new Date();
      picker.value = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');
    }
    loadAllReports();
  }

  // Called by the Refresh button — loads both sections with the same month
  window.loadAllReports = function () {
    loadInsightsSummary();
    loadAccountingSummary();
  };

  function loadInsightsSummary() {
    const picker = $('rep-month-picker');
    const month  = picker ? picker.value : '';
    const loading = $('rep-loading');
    if (loading) loading.style.display = 'inline';

    fetch(API_BASE + '/api/reports/insights-summary' + (month ? '?month=' + month : ''), { headers: authHeaders() })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        if (loading) loading.style.display = 'none';
        renderInsightsSummary(data);
      })
      .catch(function (err) {
        if (loading) loading.style.display = 'none';
        showToast('Failed to load insights: ' + (err.message || err), 'error');
      });
  }

  function renderInsightsSummary(data) {
    // Summary cards
    setText('rep-total-orders',  data.totalOrders  || 0);
    setText('rep-total-revenue', '₱' + Number(data.totalRevenue || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
    setText('rep-items-sold',    (data.totalItemsSold || 0).toLocaleString());

    // Daily breakdown chart
    const daily  = data.dailyBreakdown || [];
    const labels = daily.map(function (d) { return formatDate(d.date); });
    const values = daily.map(function (d) { return parseFloat(d.revenue) || 0; });
    renderDailyRevenueChart(labels, values);

    // Daily breakdown table
    const dtbody = $('rep-daily-tbody');
    if (dtbody) {
      if (daily.length === 0) {
        dtbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:var(--text-muted);padding:20px;">No orders this month</td></tr>';
      } else {
        dtbody.innerHTML = daily.map(function (row) {
          return '<tr>' +
            '<td>' + escapeHtml(formatDate(row.date)) + '</td>' +
            '<td style="text-align:right;">' + (row.orders || 0) + '</td>' +
            '<td style="text-align:right;">' + '₱' + Number(row.revenue || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '</td>' +
            '</tr>';
        }).join('');
      }
    }

    // Top 5 products table
    const top = data.topProducts || [];
    const ptbody = $('rep-top-products-tbody');
    if (ptbody) {
      if (top.length === 0) {
        ptbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:20px;">No sales data this month</td></tr>';
      } else {
        const medals = ['🥇','🥈','🥉','4','5'];
        ptbody.innerHTML = top.map(function (p, i) {
          return '<tr>' +
            '<td style="font-size:16px;text-align:center;">' + (medals[i] || p.rank) + '</td>' +
            '<td style="font-weight:600;">' + escapeHtml(p.name) + '</td>' +
            '<td style="text-align:right;">' + (p.qty || 0).toLocaleString() + '</td>' +
            '<td style="text-align:right;">' + '₱' + Number(p.revenue || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '</td>' +
            '<td style="text-align:right;color:var(--accent);">' + (p.pct || 0) + '%</td>' +
            '</tr>';
        }).join('');
      }
    }
  }

  function renderDailyRevenueChart(labels, values) {
    if (typeof Chart === 'undefined') { setTimeout(function () { renderDailyRevenueChart(labels, values); }, 100); return; }
    const canvas = $('chart-daily-revenue');
    if (!canvas) return;
    if (appState.chartDailyRevenue) { appState.chartDailyRevenue.destroy(); }
    const isDark = document.body.classList.contains('dark');
    const gridColor = isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
    const textColor = isDark ? '#aaa' : '#555';
    appState.chartDailyRevenue = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Revenue (₱)',
          data: values,
          backgroundColor: '#D4860A',
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: function (ctx) { return ' ₱' + Number(ctx.raw).toLocaleString('en-PH', { minimumFractionDigits: 2 }); }
            }
          }
        },
        scales: {
          x: { ticks: { color: textColor, font: { size: 10 } }, grid: { color: gridColor } },
          y: {
            ticks: {
              color: textColor,
              callback: function (v) { return '₱' + (v >= 1000 ? (v / 1000).toFixed(0) + 'K' : v); }
            },
            grid: { color: gridColor }
          }
        }
      }
    });
  }

  function setText(id, val) {
    const el = $(id);
    if (el) el.textContent = val;
  }

  // ================================================================
  // Accounting Summary (Transaction Ledger)
  // ================================================================
  function loadAccountingSummary() {
    const picker = $('rep-month-picker');
    const month  = picker ? picker.value : '';

    fetch(API_BASE + '/api/reports/accounting-summary' + (month ? '?month=' + month : ''), { headers: authHeaders() })
      .then(function (res) { return res.json(); })
      .then(function (data) { renderAccountingSummary(data); })
      .catch(function (err) {
        showToast('Failed to load accounting summary: ' + (err.message || err), 'error');
      });
  }

  function renderAccountingSummary(data) {
    const fmt = function (n) {
      const v = parseFloat(n) || 0;
      return (v < 0 ? '-₱' : '₱') + Math.abs(v).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    };
    setText('acc-gross-sales',       fmt(data.grossSales));
    setText('acc-refunds-total',     fmt(data.refundsTotal));
    setText('acc-adjustments-total', fmt(data.adjustmentsTotal));
    setText('acc-net-sales',         fmt(data.netSales));

    const daily  = data.dailyBreakdown || [];
    const tbody  = $('acc-daily-tbody');
    if (!tbody) return;
    if (daily.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:20px;">No transactions this month</td></tr>';
      return;
    }

    // Running net total row at the bottom
    let runNet = 0;
    tbody.innerHTML = daily.map(function (row) {
      const gross = parseFloat(row.grossSales)  || 0;
      const refs  = parseFloat(row.refunds)     || 0;
      const adj   = parseFloat(row.adjustments) || 0;
      const net   = parseFloat(row.netSales)    || 0;
      runNet += net;
      const netColor = net >= 0 ? '#10B981' : '#EF4444';
      return '<tr>'
        + '<td>' + escapeHtml(formatDate(row.date)) + '</td>'
        + '<td style="text-align:right;color:#10B981;">₱' + gross.toLocaleString('en-PH', { minimumFractionDigits: 2 }) + '</td>'
        + '<td style="text-align:right;color:#EF4444;">' + fmt(refs) + '</td>'
        + '<td style="text-align:right;color:#F59E0B;">' + fmt(adj)  + '</td>'
        + '<td style="text-align:right;font-weight:600;color:' + netColor + ';">' + fmt(net) + '</td>'
        + '</tr>';
    }).join('');
  }

  // ================================================================
  // Order Ledger — view transaction history for one order
  // ================================================================
  window.viewOrderLedger = function (orderId) {
    $('ledger-order-id-label').textContent = orderId;
    $('ledger-tbody').innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:20px;">Loading…</td></tr>';
    $('ledger-net').textContent = '—';
    $('modal-order-ledger').classList.add('open');

    fetch(API_BASE + '/api/transactions/order/' + encodeURIComponent(orderId), { headers: authHeaders() })
      .then(function (res) { return res.json(); })
      .then(function (txns) {
        if (!txns.length) {
          $('ledger-tbody').innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:20px;">No transactions recorded for this order</td></tr>';
          $('ledger-net').textContent = '₱0.00';
          return;
        }
        const typeColor = { SALE:'#10B981', REFUND:'#EF4444', VOID:'#EF4444', RETURN:'#EF4444', ADJUSTMENT:'#F59E0B', DISCOUNT:'#F59E0B' };
        let net = 0;
        $('ledger-tbody').innerHTML = txns.map(function (t) {
          const amt = parseFloat(t.amount) || 0;
          net += amt;
          const color = typeColor[t.transactionType] || 'inherit';
          const amtText = (amt < 0 ? '-₱' : '₱') + Math.abs(amt).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
          return '<tr>'
            + '<td><code style="font-size:11px;">' + escapeHtml(t.transactionCode) + '</code></td>'
            + '<td><span style="color:' + color + ';font-weight:600;font-size:12px;">' + escapeHtml(t.transactionType) + '</span></td>'
            + '<td style="text-align:right;color:' + color + ';font-weight:600;">' + amtText + '</td>'
            + '<td>' + (t.effectiveDate ? formatDate(t.effectiveDate) : '—') + '</td>'
            + '<td style="font-size:12px;color:var(--text-muted);">' + escapeHtml(t.notes || '—') + '</td>'
            + '</tr>';
        }).join('');
        const netColor = net >= 0 ? '#10B981' : '#EF4444';
        const netText  = (net < 0 ? '-₱' : '₱') + Math.abs(net).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        $('ledger-net').textContent  = netText;
        $('ledger-net').style.color  = netColor;
      })
      .catch(function () {
        $('ledger-tbody').innerHTML = '<tr><td colspan="5" style="text-align:center;color:#EF4444;">Failed to load ledger</td></tr>';
      });
  };

  // ================================================================
  // Refund
  // ================================================================
  window.askRefund = function (orderId, total) {
    appState.refundTargetId = orderId;
    $('refund-order-id').textContent    = orderId;
    $('refund-order-total').textContent = '₱' + Number(total).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    $('refund-amount').value  = '';
    $('refund-amount').max    = total;
    $('refund-reason').value  = '';
    $('modal-refund').classList.add('open');
  };

  window.confirmRefund = async function () {
    const orderId = appState.refundTargetId;
    const amount  = ($('refund-amount').value  || '').trim();
    const reason  = ($('refund-reason').value  || '').trim();
    if (!amount || parseFloat(amount) <= 0) { showToast('Enter a valid refund amount', 'error'); return; }
    if (!reason) { showToast('Reason is required', 'error'); return; }

    try {
      const res = await fetch(API_BASE + '/api/transactions/refund', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ orderId, amount, reason })
      });
      const data = await res.json();
      if (!res.ok) { showToast('Refund failed: ' + (data.message || res.status), 'error'); return; }
      closeModal('modal-refund');
      showToast('Refund of ₱' + amount + ' recorded for order ' + orderId, 'success');
    } catch (err) {
      showToast('Error: ' + err.message, 'error');
    }
  };

  // ================================================================
  // Post-Close Void
  // ================================================================
  window.askVoid = function (orderId, total) {
    appState.voidTargetId = orderId;
    $('void-order-id').textContent    = orderId;
    $('void-order-total').textContent = '₱' + Number(total).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    $('void-amount').value  = Number(total).toFixed(2);
    $('void-amount').max    = total;
    $('void-reason').value  = '';
    $('modal-void').classList.add('open');
  };

  window.confirmVoid = async function () {
    const orderId = appState.voidTargetId;
    const amount  = ($('void-amount').value  || '').trim();
    const reason  = ($('void-reason').value  || '').trim();
    if (!amount || parseFloat(amount) <= 0) { showToast('Enter a valid void amount', 'error'); return; }
    if (!reason) { showToast('Reason is required', 'error'); return; }

    try {
      const res = await fetch(API_BASE + '/api/transactions/void', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ orderId, amount, reason })
      });
      const data = await res.json();
      if (!res.ok) { showToast('Void failed: ' + (data.message || res.status), 'error'); return; }
      closeModal('modal-void');
      showToast('Post-close void of ₱' + amount + ' recorded for order ' + orderId, 'success');
    } catch (err) {
      showToast('Error: ' + err.message, 'error');
    }
  };

  // ================================================================
  // Initialization
  // ================================================================
  document.addEventListener('DOMContentLoaded', function () {
    setInterval(updateClock, 1000);
    updateClock();
    setTimeout(initDashboardCharts, 100); // create empty chart containers at load time
    const today = new Date().toISOString().split('T')[0];
    if ($('delivery-rep-date'))  $('delivery-rep-date').value  = today;
    if ($('activity-log-date'))  $('activity-log-date').value  = today;

    // Hide role-restricted items until login
    applyRoleRestrictions(null);
  });

})();
