package rrbm_backend;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
public class OrderService {
    
    private final OrderRepository orderRepository;
    private final OrderIdGenerator orderIdGenerator;
    private final UserRepository userRepository;
    
    public OrderService(OrderRepository orderRepository, 
                       OrderIdGenerator orderIdGenerator,
                       UserRepository userRepository) {
        this.orderRepository = orderRepository;
        this.orderIdGenerator = orderIdGenerator;
        this.userRepository = userRepository;
    }
    
    /**
     * Create a new order with items
     */
    @Transactional
    public Order createOrder(Order order, Long createdByUserId) {
        // Generate unique order ID
        String orderId = orderIdGenerator.generateOrderId();
        order.setId(orderId);
        
        // Set created by user
        User creator = userRepository.findById(createdByUserId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        order.setCreatedBy(creator);
        
        // Link all items to this order
        order.getItems().forEach(item -> item.setOrder(order));
        
        // Calculate totals
        order.calculateTotals();
        
        // Save order (cascade will save items too)
        return orderRepository.save(order);
    }
    
    /**
     * Get today's orders
     */
    public List<Order> getTodaysOrders() {
        return orderRepository.findByCreatedAtDate(LocalDate.now());
    }
    
    /**
     * Get all orders
     */
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
    
    /**
     * Get order by ID
     */
    public Order getOrderById(String orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));
    }
    
    /**
     * Cancel order with master key validation
     */
    @Transactional
    public Order cancelOrder(String orderId, String masterKey, Long cancelledByUserId, String reason) {
        // TODO: Validate master key against settings table
        // For now, we'll implement this in the next iteration
        
        Order order = getOrderById(orderId);
        
        if ("CANCELLED".equals(order.getStatus())) {
            throw new RuntimeException("Order is already cancelled");
        }
        
        User cancelledBy = userRepository.findById(cancelledByUserId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        order.setStatus("CANCELLED");
        order.setCancelledBy(cancelledBy);
        order.setCancelledAt(java.time.LocalDateTime.now());
        order.setCancellationReason(reason);
        
        return orderRepository.save(order);
    }
    
    /**
     * Search orders by customer name
     */
    public List<Order> searchByCustomerName(String customerName) {
        return orderRepository.findByCustomerNameContainingIgnoreCaseOrderByCreatedAtDesc(customerName);
    }
}