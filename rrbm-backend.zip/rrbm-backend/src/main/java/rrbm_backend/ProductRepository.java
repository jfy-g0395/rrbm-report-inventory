package rrbm_backend;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

// This interface gives us all basic database operations (findAll, findById, save, delete)
// for free — Spring generates the actual code behind the scenes.
// We just add custom query methods by naming them a certain way.
public interface ProductRepository extends JpaRepository<Product, Long> {

    // Spring reads the method name and auto-generates the SQL:
    // SELECT * FROM products WHERE active = true ORDER BY name ASC
    List<Product> findByActiveTrueOrderByNameAsc();

    // SELECT * FROM products WHERE category = ? AND active = true
    List<Product> findByCategoryAndActiveTrue(String category);

    // SELECT * FROM products WHERE LOWER(name) LIKE LOWER('%search%') AND active = true
    List<Product> findByNameContainingIgnoreCaseAndActiveTrue(String name);
}
