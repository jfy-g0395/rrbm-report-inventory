package rrbm_backend;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "*")  // Allow frontend to call this endpoint
public class ProductController {

    // Spring automatically injects the ProductRepository here (constructor injection)
    private final ProductRepository productRepository;

    public ProductController(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    // GET /api/products — returns all active products, sorted by name
    // This is what the frontend autofill dropdown will call.
    // It returns the full product info so the frontend can auto-populate
    // the unit price when a product is selected.
    @GetMapping
    public List<Product> getAllActiveProducts() {
        return productRepository.findByActiveTrueOrderByNameAsc();
    }

    // GET /api/products/search?name=pizza — search products by name
    // This supports the autocomplete/search-as-you-type feature
    @GetMapping("/search")
    public List<Product> searchProducts(@RequestParam String name) {
        return productRepository.findByNameContainingIgnoreCaseAndActiveTrue(name);
    }

    // GET /api/products/all — returns ALL products including inactive (for admin/inventory)
    @GetMapping("/all")
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }
}
