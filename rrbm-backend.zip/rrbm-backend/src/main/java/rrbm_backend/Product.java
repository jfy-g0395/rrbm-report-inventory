package rrbm_backend;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "products")
public class Product {

    // This maps to the "id" column in your products table.
    // IDENTITY means PostgreSQL auto-generates the ID (BIGSERIAL).
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Maps to "name" column — e.g. "Pizza Box 10\" White"
    @Column(nullable = false)
    private String name;

    // Maps to "category" column — e.g. "Pizza Box", "Packaging", etc.
    private String category;

    // Maps to "unit_price" — the default selling price per piece/unit
    @Column(name = "unit_price")
    private BigDecimal unitPrice;

    // Maps to "current_stock" — how many units are in stock right now
    @Column(name = "current_stock")
    private Integer currentStock;

    // Maps to "reorder_level" — when stock drops below this, show warning
    @Column(name = "reorder_level")
    private Integer reorderLevel;

    // Maps to "unit" — e.g. "pcs", "box", "ream"
    private String unit;

    // Maps to "warehouse" — which warehouse stores this product
    private String warehouse;

    // Maps to "active" — soft delete flag (false = discontinued)
    private Boolean active;

    // Maps to "created_at" — auto-set when product is first created
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    // Maps to "updated_at" — auto-set when product is modified
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // --- Constructors ---

    // JPA requires an empty constructor
    public Product() {}

    // --- Getters and Setters ---
    // Every field needs a getter and setter so Spring/JPA can read and write values.

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice) { this.unitPrice = unitPrice; }

    public Integer getCurrentStock() { return currentStock; }
    public void setCurrentStock(Integer currentStock) { this.currentStock = currentStock; }

    public Integer getReorderLevel() { return reorderLevel; }
    public void setReorderLevel(Integer reorderLevel) { this.reorderLevel = reorderLevel; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public String getWarehouse() { return warehouse; }
    public void setWarehouse(String warehouse) { this.warehouse = warehouse; }

    public Boolean getActive() { return active; }
    public void setActive(Boolean active) { this.active = active; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
