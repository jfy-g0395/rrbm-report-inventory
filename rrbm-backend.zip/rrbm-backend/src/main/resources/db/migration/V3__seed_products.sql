-- V3__seed_products.sql
-- Seeds the products table with RRBM's pizza box and packaging products.
-- These are the items that will appear in the order form dropdown.
-- You can add/edit/remove products later through the Inventory module (Phase 4).

INSERT INTO products (name, category, unit_price, current_stock, reorder_level, unit, warehouse, active, created_at, updated_at) VALUES
-- Pizza Boxes (main product line)
('Pizza Box 8" Brown',       'Pizza Box',  8.00,   500,  100, 'pcs', 'WH1', true, NOW(), NOW()),
('Pizza Box 8" White',       'Pizza Box',  9.00,   500,  100, 'pcs', 'WH1', true, NOW(), NOW()),
('Pizza Box 10" Brown',      'Pizza Box', 12.00,  1000,  200, 'pcs', 'WH1', true, NOW(), NOW()),
('Pizza Box 10" White',      'Pizza Box', 13.00,  1000,  200, 'pcs', 'WH1', true, NOW(), NOW()),
('Pizza Box 12" Brown',      'Pizza Box', 15.00,   800,  150, 'pcs', 'WH1', true, NOW(), NOW()),
('Pizza Box 12" White',      'Pizza Box', 16.00,   800,  150, 'pcs', 'WH1', true, NOW(), NOW()),
('Pizza Box 14" Brown',      'Pizza Box', 18.00,   600,  100, 'pcs', 'WH1', true, NOW(), NOW()),
('Pizza Box 14" White',      'Pizza Box', 19.00,   600,  100, 'pcs', 'WH1', true, NOW(), NOW()),
('Pizza Box 16" Brown',      'Pizza Box', 22.00,   400,   80, 'pcs', 'WH1', true, NOW(), NOW()),
('Pizza Box 16" White',      'Pizza Box', 23.00,   400,   80, 'pcs', 'WH1', true, NOW(), NOW()),
('Pizza Box 18" Brown',      'Pizza Box', 28.00,   300,   60, 'pcs', 'WH1', true, NOW(), NOW()),
('Pizza Box 18" White',      'Pizza Box', 30.00,   300,   60, 'pcs', 'WH1', true, NOW(), NOW()),

-- Pastry Boxes
('Pastry Box 6x6x3 Brown',   'Pastry Box',  6.00,   400,   80, 'pcs', 'WH1', true, NOW(), NOW()),
('Pastry Box 6x6x3 White',   'Pastry Box',  7.00,   400,   80, 'pcs', 'WH1', true, NOW(), NOW()),
('Pastry Box 8x8x3 Brown',   'Pastry Box',  8.00,   300,   60, 'pcs', 'WH1', true, NOW(), NOW()),
('Pastry Box 8x8x3 White',   'Pastry Box',  9.00,   300,   60, 'pcs', 'WH1', true, NOW(), NOW()),
('Pastry Box 10x10x4 Brown', 'Pastry Box', 12.00,   200,   50, 'pcs', 'WH1', true, NOW(), NOW()),
('Pastry Box 10x10x4 White', 'Pastry Box', 13.00,   200,   50, 'pcs', 'WH1', true, NOW(), NOW()),

-- Food Trays & Containers
('Food Tray Small Brown',    'Food Tray',   4.00,   600,  100, 'pcs', 'WH1', true, NOW(), NOW()),
('Food Tray Medium Brown',   'Food Tray',   5.50,   500,  100, 'pcs', 'WH1', true, NOW(), NOW()),
('Food Tray Large Brown',    'Food Tray',   7.00,   400,   80, 'pcs', 'WH1', true, NOW(), NOW()),

-- Packaging Supplies
('Packaging Tape 2" Clear',  'Supplies',    35.00,  200,   50, 'pcs', 'WH2', true, NOW(), NOW()),
('Packaging Tape 2" Brown',  'Supplies',    33.00,  200,   50, 'pcs', 'WH2', true, NOW(), NOW()),
('Bubble Wrap 12" x 50m',    'Supplies',   180.00,   50,   10, 'roll', 'WH2', true, NOW(), NOW()),
('Stretch Film 18" x 300m',  'Supplies',   250.00,   40,   10, 'roll', 'WH2', true, NOW(), NOW());
